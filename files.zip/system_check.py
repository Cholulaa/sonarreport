#!/usr/bin/env python3
"""
Script de diagnostic système pour SonarQube Reporter
Vérifie tous les prérequis et la configuration de l'environnement
"""

import sys
import os
import subprocess
import platform

def run_command(command, description=""):
    """Exécute une commande et retourne le résultat."""
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
        return result.returncode == 0, result.stdout.strip(), result.stderr.strip()
    except subprocess.TimeoutExpired:
        return False, "", "Timeout"
    except Exception as e:
        return False, "", str(e)

def check_system():
    """Vérifie les informations système."""
    print("=== INFORMATIONS SYSTÈME ===")
    print(f"Serveur: csi-sec-snq-cli-dev-01")
    print(f"OS: {platform.system()} {platform.release()}")
    print(f"Architecture: {platform.machine()}")
    print(f"Python: {sys.version}")
    print(f"Utilisateur: {os.getenv('USER', 'inconnu')}")
    print(f"Répertoire courant: {os.getcwd()}")
    print(f"Répertoire attendu: /home/scsq-devops/reporting/sonarreport")
    
    # Vérification du répertoire
    expected_dir = "/home/scsq-devops/reporting/sonarreport"
    current_dir = os.getcwd()
    if current_dir == expected_dir:
        print("✓ Répertoire correct")
    else:
        print(f"⚠ Répertoire différent de celui attendu")
    
    print(f"PATH: {os.getenv('PATH', 'non défini')[:100]}...")
    print()

def check_python():
    """Vérifie l'installation de Python."""
    print("=== VÉRIFICATION PYTHON ===")
    
    # Version Python
    version = sys.version_info
    if version.major >= 3 and version.minor >= 7:
        print(f"✓ Version Python: {version.major}.{version.minor}.{version.micro} (OK)")
    else:
        print(f"✗ Version Python: {version.major}.{version.minor}.{version.micro} (Python 3.7+ requis)")
        return False
    
    # Pip
    success, output, error = run_command("python3 -m pip --version")
    if success:
        print(f"✓ Pip disponible: {output.split()[1] if output else 'version inconnue'}")
    else:
        print(f"✗ Pip non disponible: {error}")
        return False
    
    print()
    return True

def check_python_modules():
    """Vérifie les modules Python requis."""
    print("=== VÉRIFICATION MODULES PYTHON ===")
    
    modules = {
        'requests': 'Communication avec l\'API SonarQube',
        'pandas': 'Manipulation des données',
        'reportlab': 'Génération de PDF',
        'PIL': 'Traitement d\'images (Pillow)',
        'configparser': 'Lecture de la configuration',
        'smtplib': 'Envoi d\'emails (standard)',
        'ssl': 'Sécurité SSL (standard)',
        'email': 'Gestion emails (standard)',
        'json': 'Format JSON (standard)',
        'datetime': 'Gestion des dates (standard)',
        'logging': 'Système de logs (standard)'
    }
    
    all_ok = True
    for module, description in modules.items():
        try:
            if module == 'PIL':
                import PIL
                from PIL import Image
                print(f"✓ {module}: {description} (version {PIL.__version__})")
            elif module == 'reportlab':
                import reportlab
                print(f"✓ {module}: {description} (version {reportlab.Version})")
            elif module == 'requests':
                import requests
                print(f"✓ {module}: {description} (version {requests.__version__})")
            elif module == 'pandas':
                import pandas
                print(f"✓ {module}: {description} (version {pandas.__version__})")
            else:
                exec(f"import {module}")
                print(f"✓ {module}: {description}")
        except ImportError as e:
            print(f"✗ {module}: {description} - MANQUANT ({e})")
            all_ok = False
        except Exception as e:
            print(f"⚠ {module}: {description} - ERREUR ({e})")
    
    print()
    return all_ok

def check_system_tools():
    """Vérifie les outils système."""
    print("=== VÉRIFICATION OUTILS SYSTÈME ===")
    
    tools = {
        'crontab': 'Planificateur de tâches',
        'curl': 'Client HTTP (optionnel)',
        'wget': 'Téléchargeur (optionnel)'
    }
    
    for tool, description in tools.items():
        success, output, error = run_command(f"which {tool}")
        if success:
            print(f"✓ {tool}: {description} ({output})")
        else:
            print(f"✗ {tool}: {description} - NON TROUVÉ")
    
    # Vérification spécifique de cron
    success, output, error = run_command("systemctl is-active cron")
    if success:
        print("✓ Service cron: ACTIF")
    else:
        success, output, error = run_command("systemctl is-active crond")
        if success:
            print("✓ Service crond: ACTIF")
        else:
            print("⚠ Service cron: STATUT INCONNU")
    
    print()

def check_network():
    """Vérifie la connectivité réseau."""
    print("=== VÉRIFICATION RÉSEAU ===")
    
    # Test de connectivité basique
    success, output, error = run_command("ping -c 1 google.com")
    if success:
        print("✓ Connectivité internet: OK")
    else:
        print("✗ Connectivité internet: PROBLÈME")
        return False
    
    # Test HTTPS
    try:
        import requests
        response = requests.get("https://httpbin.org/get", timeout=5)
        if response.status_code == 200:
            print("✓ Connectivité HTTPS: OK")
        else:
            print(f"⚠ Connectivité HTTPS: Code {response.status_code}")
    except Exception as e:
        print(f"✗ Connectivité HTTPS: ERREUR ({e})")
    
    print()

def check_files():
    """Vérifie les fichiers du projet."""
    print("=== VÉRIFICATION FICHIERS ===")
    
    required_files = {
        'sonarqube_monthly_report.py': 'Script principal',
        'config.ini': 'Configuration',
        'test_config.py': 'Script de test',
        'install_dependencies.sh': 'Installation complète',
        'install_dependencies_user.sh': 'Installation utilisateur',
        'crontab_config': 'Configuration cron',
        'README.md': 'Documentation'
    }
    
    for filename, description in required_files.items():
        if os.path.exists(filename):
            size = os.path.getsize(filename)
            if os.access(filename, os.R_OK):
                perm = "✓"
            else:
                perm = "✗ (non lisible)"
            print(f"✓ {filename}: {description} ({size} bytes) {perm}")
        else:
            print(f"✗ {filename}: {description} - MANQUANT")
    
    # Vérification des dossiers
    directories = ['logs', 'reports', 'backup']
    for directory in directories:
        if os.path.exists(directory):
            if os.path.isdir(directory) and os.access(directory, os.W_OK):
                print(f"✓ {directory}/: Dossier accessible en écriture")
            else:
                print(f"⚠ {directory}/: Dossier sans permission d'écriture")
        else:
            print(f"- {directory}/: Sera créé automatiquement")
    
    print()

def check_permissions():
    """Vérifie les permissions des fichiers."""
    print("=== VÉRIFICATION PERMISSIONS ===")
    
    scripts = ['sonarqube_monthly_report.py', 'test_config.py']
    for script in scripts:
        if os.path.exists(script):
            if os.access(script, os.X_OK):
                print(f"✓ {script}: Exécutable")
            else:
                print(f"⚠ {script}: Non exécutable (chmod +x {script})")
        
    if os.path.exists('config.ini'):
        stat_info = os.stat('config.ini')
        permissions = oct(stat_info.st_mode)[-3:]
        if permissions == '600':
            print("✓ config.ini: Permissions sécurisées (600)")
        else:
            print(f"⚠ config.ini: Permissions {permissions} (recommandé: 600)")
    
    print()

def generate_installation_command():
    """Génère la commande d'installation appropriée."""
    print("=== RECOMMANDATIONS D'INSTALLATION ===")
    
    has_sudo = run_command("sudo -n true")[0]
    
    if has_sudo:
        print("✓ Droits sudo disponibles")
        print("→ Utilisez: ./install_dependencies.sh")
    else:
        print("⚠ Pas de droits sudo")
        print("→ Utilisez: ./install_dependencies_user.sh")
    
    # Détection du gestionnaire de paquets
    package_managers = {
        'apt-get': 'Debian/Ubuntu',
        'yum': 'RedHat/CentOS',
        'dnf': 'Fedora',
        'pacman': 'Arch Linux',
        'brew': 'macOS'
    }
    
    for pm, distro in package_managers.items():
        if run_command(f"which {pm}")[0]:
            print(f"→ Gestionnaire de paquets détecté: {pm} ({distro})")
            break
    
    print()

def main():
    """Point d'entrée principal."""
    print("🔍 DIAGNOSTIC SYSTÈME - SonarQube Reporter")
    print("=" * 50)
    
    # Exécution de tous les tests
    check_system()
    python_ok = check_python()
    modules_ok = check_python_modules()
    check_system_tools()
    check_network()
    check_files()
    check_permissions()
    generate_installation_command()
    
    # Résumé
    print("=== RÉSUMÉ ===")
    if python_ok and modules_ok:
        print("✅ Système prêt pour SonarQube Reporter")
        print("📋 Prochaines étapes:")
        print("   1. Configurez config.ini")
        print("   2. Testez: python3 test_config.py")
        print("   3. Exécutez: python3 sonarqube_monthly_report.py")
    else:
        print("❌ Installation requise")
        print("📋 Actions nécessaires:")
        if not python_ok:
            print("   - Installez Python 3.7+ et pip")
        if not modules_ok:
            print("   - Installez les modules Python manquants")
        print("   - Relancez ce diagnostic après installation")
    
    return 0 if (python_ok and modules_ok) else 1

if __name__ == "__main__":
    exit(main())
