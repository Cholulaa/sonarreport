#!/usr/bin/env python3
"""
SonarQube Monthly Report Generator
Génère et envoie un rapport mensuel pour tous les projets SonarQube
"""

import requests
import json
import smtplib
import ssl
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
import base64
import logging
import os
from typing import Dict, List, Optional
import configparser

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SonarQubeReporter:
    def __init__(self, config_file: str = 'config.ini'):
        """Initialise le générateur de rapports SonarQube."""
        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        
        # Configuration SonarQube
        self.sonar_url = self.config.get('sonarqube', 'url')
        self.sonar_token = self.config.get('sonarqube', 'token', fallback=None)
        self.sonar_user = self.config.get('sonarqube', 'username', fallback=None)
        self.sonar_password = self.config.get('sonarqube', 'password', fallback=None)
        
        # Configuration Email
        self.smtp_server = self.config.get('email', 'smtp_server')
        self.smtp_port = self.config.getint('email', 'smtp_port')
        self.email_user = self.config.get('email', 'username')
        self.email_password = self.config.get('email', 'password')
        self.recipients = self.config.get('email', 'recipients').split(',')
        
        # Configuration du rapport
        self.report_title = self.config.get('report', 'title', fallback='Rapport Mensuel SonarQube')
        
        # Headers pour les requêtes API
        self.headers = {'Content-Type': 'application/json'}
        if self.sonar_token:
            self.auth = (self.sonar_token, '')
        else:
            self.auth = (self.sonar_user, self.sonar_password)

    def get_projects(self) -> List[Dict]:
        """Récupère la liste de tous les projets SonarQube."""
        try:
            url = f"{self.sonar_url}/api/projects/search"
            response = requests.get(url, auth=self.auth, headers=self.headers)
            response.raise_for_status()
            
            data = response.json()
            projects = data.get('components', [])
            logger.info(f"Trouvé {len(projects)} projets")
            return projects
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des projets: {e}")
            return []

    def get_project_metrics(self, project_key: str) -> Dict:
        """Récupère les métriques d'un projet spécifique."""
        metrics = [
            'ncloc', 'lines', 'files', 'functions', 'classes',
            'bugs', 'vulnerabilities', 'code_smells',
            'coverage', 'duplicated_lines_density',
            'sqale_rating', 'reliability_rating', 'security_rating',
            'complexity', 'cognitive_complexity'
        ]
        
        try:
            url = f"{self.sonar_url}/api/measures/component"
            params = {
                'component': project_key,
                'metricKeys': ','.join(metrics)
            }
            
            response = requests.get(url, auth=self.auth, headers=self.headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            component = data.get('component', {})
            measures = component.get('measures', [])
            
            # Organise les métriques en dictionnaire
            metrics_dict = {
                'project_key': project_key,
                'project_name': component.get('name', project_key)
            }
            
            for measure in measures:
                metric_key = measure.get('metric')
                value = measure.get('value', '0')
                metrics_dict[metric_key] = value
            
            return metrics_dict
            
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des métriques pour {project_key}: {e}")
            return {'project_key': project_key, 'project_name': project_key}

    def get_project_issues(self, project_key: str) -> Dict:
        """Récupère les issues d'un projet."""
        try:
            url = f"{self.sonar_url}/api/issues/search"
            params = {
                'componentKeys': project_key,
                'resolved': 'false',
                'ps': 1,  # On veut juste le count
                'facets': 'severities,types'
            }
            
            response = requests.get(url, auth=self.auth, headers=self.headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            total_issues = data.get('total', 0)
            facets = data.get('facets', [])
            
            issues_summary = {
                'total_issues': total_issues,
                'by_severity': {},
                'by_type': {}
            }
            
            for facet in facets:
                if facet.get('property') == 'severities':
                    for value in facet.get('values', []):
                        issues_summary['by_severity'][value.get('val')] = value.get('count')
                elif facet.get('property') == 'types':
                    for value in facet.get('values', []):
                        issues_summary['by_type'][value.get('val')] = value.get('count')
            
            return issues_summary
            
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des issues pour {project_key}: {e}")
            return {'total_issues': 0, 'by_severity': {}, 'by_type': {}}

    def generate_summary_data(self, projects_data: List[Dict]) -> Dict:
        """Génère les données de résumé global."""
        total_projects = len(projects_data)
        total_lines = sum(int(p.get('ncloc', 0) or 0) for p in projects_data)
        total_bugs = sum(int(p.get('bugs', 0) or 0) for p in projects_data)
        total_vulnerabilities = sum(int(p.get('vulnerabilities', 0) or 0) for p in projects_data)
        total_code_smells = sum(int(p.get('code_smells', 0) or 0) for p in projects_data)
        
        # Calcul de la couverture moyenne
        coverages = [float(p.get('coverage', 0) or 0) for p in projects_data if p.get('coverage')]
        avg_coverage = sum(coverages) / len(coverages) if coverages else 0
        
        # Projets avec des problèmes critiques
        projects_with_bugs = len([p for p in projects_data if int(p.get('bugs', 0) or 0) > 0])
        projects_with_vulnerabilities = len([p for p in projects_data if int(p.get('vulnerabilities', 0) or 0) > 0])
        
        return {
            'total_projects': total_projects,
            'total_lines': total_lines,
            'total_bugs': total_bugs,
            'total_vulnerabilities': total_vulnerabilities,
            'total_code_smells': total_code_smells,
            'avg_coverage': round(avg_coverage, 2),
            'projects_with_bugs': projects_with_bugs,
            'projects_with_vulnerabilities': projects_with_vulnerabilities
        }

    def create_pdf_report(self, projects_data: List[Dict], summary: Dict, filename: str):
        """Crée un rapport PDF."""
        doc = SimpleDocTemplate(filename, pagesize=A4)
        elements = []
        styles = getSampleStyleSheet()
        
        # Titre principal
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=20,
            spaceAfter=30,
            textColor=colors.darkblue,
            alignment=1  # Center
        )
        
        current_date = datetime.now().strftime("%B %Y")
        title = Paragraph(f"{self.report_title} - {current_date}", title_style)
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Résumé exécutif
        summary_style = ParagraphStyle(
            'SummaryStyle',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=colors.darkgreen
        )
        
        elements.append(Paragraph("Résumé Exécutif", summary_style))
        elements.append(Spacer(1, 10))
        
        summary_data = [
            ['Métrique', 'Valeur'],
            ['Nombre total de projets', str(summary['total_projects'])],
            ['Lignes de code totales', f"{summary['total_lines']:,}"],
            ['Bugs totaux', str(summary['total_bugs'])],
            ['Vulnérabilités totales', str(summary['total_vulnerabilities'])],
            ['Code smells totaux', str(summary['total_code_smells'])],
            ['Couverture moyenne', f"{summary['avg_coverage']}%"],
            ['Projets avec bugs', str(summary['projects_with_bugs'])],
            ['Projets avec vulnérabilités', str(summary['projects_with_vulnerabilities'])]
        ]
        
        summary_table = Table(summary_data)
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
        elements.append(PageBreak())
        
        # Détails par projet
        elements.append(Paragraph("Détails par Projet", summary_style))
        elements.append(Spacer(1, 20))
        
        # En-têtes du tableau
        project_headers = [
            'Projet', 'Lignes', 'Bugs', 'Vulnérabilités', 
            'Code Smells', 'Couverture (%)', 'Note Qualité'
        ]
        
        project_data = [project_headers]
        
        for project in projects_data:
            # Détermine la note de qualité basée sur les ratings
            sqale_rating = project.get('sqale_rating', 'A')
            reliability_rating = project.get('reliability_rating', 'A')
            security_rating = project.get('security_rating', 'A')
            
            # Note globale (simplifié)
            ratings = [sqale_rating, reliability_rating, security_rating]
            worst_rating = max(ratings) if ratings else 'A'
            
            project_data.append([
                project.get('project_name', 'N/A')[:30],  # Tronque les noms longs
                project.get('ncloc', '0'),
                project.get('bugs', '0'),
                project.get('vulnerabilities', '0'),
                project.get('code_smells', '0'),
                project.get('coverage', '0'),
                worst_rating
            ])
        
        project_table = Table(project_data)
        project_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(project_table)
        
        # Footer avec date de génération
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=8,
            textColor=colors.grey
        )
        elements.append(Spacer(1, 30))
        elements.append(Paragraph(f"Rapport généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}", footer_style))
        
        doc.build(elements)
        logger.info(f"Rapport PDF généré: {filename}")

    def send_email_report(self, pdf_filename: str, summary: Dict):
        """Envoie le rapport par email."""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_user
            msg['To'] = ', '.join(self.recipients)
            msg['Subject'] = f"Rapport Mensuel SonarQube - {datetime.now().strftime('%B %Y')}"
            
            # Corps de l'email
            body = f"""
Bonjour,

Veuillez trouver en pièce jointe le rapport mensuel SonarQube.

Résumé:
- Projets analysés: {summary['total_projects']}
- Lignes de code totales: {summary['total_lines']:,}
- Bugs: {summary['total_bugs']}
- Vulnérabilités: {summary['total_vulnerabilities']}
- Couverture moyenne: {summary['avg_coverage']}%

Cordialement,
Système de reporting SonarQube
"""
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Pièce jointe PDF
            with open(pdf_filename, "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            
            encoders.encode_base64(part)
            part.add_header(
                'Content-Disposition',
                f'attachment; filename= {os.path.basename(pdf_filename)}'
            )
            msg.attach(part)
            
            # Envoi
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.email_user, self.email_password)
                text = msg.as_string()
                server.sendmail(self.email_user, self.recipients, text)
            
            logger.info(f"Rapport envoyé par email à: {', '.join(self.recipients)}")
            
        except Exception as e:
            logger.error(f"Erreur lors de l'envoi de l'email: {e}")
            raise

    def generate_monthly_report(self):
        """Génère le rapport mensuel complet."""
        logger.info("Début de la génération du rapport mensuel SonarQube")
        
        try:
            # Récupération des projets
            projects = self.get_projects()
            if not projects:
                logger.warning("Aucun projet trouvé")
                return
            
            # Récupération des métriques pour chaque projet
            projects_data = []
            for project in projects:
                project_key = project['key']
                logger.info(f"Traitement du projet: {project_key}")
                
                metrics = self.get_project_metrics(project_key)
                projects_data.append(metrics)
            
            # Génération du résumé
            summary = self.generate_summary_data(projects_data)
            
            # Création du fichier PDF
            timestamp = datetime.now().strftime("%Y%m")
            pdf_filename = f"rapport_sonarqube_{timestamp}.pdf"
            
            self.create_pdf_report(projects_data, summary, pdf_filename)
            
            # Envoi par email
            self.send_email_report(pdf_filename, summary)
            
            logger.info("Rapport mensuel généré et envoyé avec succès!")
            
        except Exception as e:
            logger.error(f"Erreur lors de la génération du rapport: {e}")
            raise

def main():
    """Point d'entrée principal."""
    try:
        reporter = SonarQubeReporter()
        reporter.generate_monthly_report()
    except Exception as e:
        logger.error(f"Erreur fatale: {e}")
        return 1
    return 0

if __name__ == "__main__":
    exit(main())
