#!/bin/bash

# Script de déploiement pour scsq-devops@csi-sec-snq-cli-dev-01
# Répertoire: /home/scsq-devops/reporting/sonarreport

echo "=== Déploiement SonarQube Reporter pour scsq-devops ==="
echo "Répertoire cible: /home/scsq-devops/reporting/sonarreport"
echo "Utilisateur: $(whoami)"
echo "Date: $(date)"
echo ""

# Vérification que nous sommes dans le bon répertoire
EXPECTED_DIR="/home/scsq-devops/reporting/sonarreport"
CURRENT_DIR=$(pwd)

if [ "$CURRENT_DIR" != "$EXPECTED_DIR" ]; then
    echo "⚠️  ATTENTION: Répertoire inattendu"
    echo "   Attendu: $EXPECTED_DIR"
    echo "   Actuel:  $CURRENT_DIR"
    echo ""
    read -p "Continuer quand même ? (y/N): " confirm
    if [[ $confirm != [yY] ]]; then
        echo "Déploiement annulé."
        exit 1
    fi
fi

echo "=== 1. Vérification de l'environnement ==="
python3 system_check.py
echo ""

echo "=== 2. Installation des dépendances ==="
if sudo -n true 2>/dev/null; then
    echo "Droits sudo disponibles - Installation complète"
    ./install_dependencies.sh
else
    echo "Pas de droits sudo - Installation utilisateur"
    ./install_dependencies_user.sh
fi
echo ""

echo "=== 3. Configuration des permissions ==="
chmod +x sonarqube_monthly_report.py
chmod +x test_config.py
chmod +x system_check.py
chmod 600 config.ini 2>/dev/null || echo "config.ini sera sécurisé après configuration"
echo "✓ Permissions configurées"
echo ""

echo "=== 4. Création de la structure de répertoires ==="
mkdir -p logs reports backup
echo "✓ Dossiers créés:"
echo "  - logs/ (journaux d'exécution)"
echo "  - reports/ (rapports PDF)"
echo "  - backup/ (sauvegardes)"
echo ""

echo "=== 5. Configuration du chemin Python pour cron ==="
PYTHON_PATH=$(which python3)
echo "Python trouvé: $PYTHON_PATH"

# Mise à jour du crontab avec le bon chemin Python si différent
if [ "$PYTHON_PATH" != "/usr/bin/python3" ]; then
    echo "⚠️  Python n'est pas dans /usr/bin/python3"
    echo "Mise à jour du crontab_config avec le chemin correct..."
    
    # Création d'un crontab personnalisé
    cp crontab_config crontab_config.backup
    sed "s|/usr/bin/python3|$PYTHON_PATH|g" crontab_config > crontab_config.custom
    echo "✓ Crontab personnalisé créé: crontab_config.custom"
    echo "  Utilisez: crontab crontab_config.custom"
fi
echo ""

echo "=== 6. Test de l'installation ==="
echo "Test de la configuration..."
if python3 test_config.py; then
    echo "✅ Configuration valide"
else
    echo "❌ Erreurs de configuration détectées"
    echo "   Éditez config.ini avant de continuer"
fi
echo ""

echo "=== 7. Instructions finales ==="
echo "📋 Configuration requise dans config.ini:"
echo "   [sonarqube]"
echo "   url = http://your-sonarqube-server:9000"
echo "   token = your_sonarqube_token"
echo ""
echo "   [email]"
echo "   smtp_server = your-smtp-server"
echo "   username = your-email@company.com"
echo "   password = your-email-password"
echo "   recipients = recipient1@company.com,recipient2@company.com"
echo ""

echo "🚀 Commandes de test:"
echo "   python3 test_config.py                    # Test configuration"
echo "   python3 sonarqube_monthly_report.py       # Test génération rapport"
echo ""

echo "⏰ Installation du cron:"
if [ -f "crontab_config.custom" ]; then
    echo "   crontab crontab_config.custom              # Version personnalisée"
else
    echo "   crontab crontab_config                     # Version standard"
fi
echo "   crontab -l                                 # Vérification"
echo ""

echo "📊 Surveillance:"
echo "   tail -f logs/sonarqube_report.log         # Logs en temps réel"
echo "   ls -la reports/                           # Rapports générés"
echo ""

echo "✅ Déploiement terminé !"
echo "Répertoire: $(pwd)"
echo "Fichiers installés: $(ls -1 *.py *.sh *.ini *.md | wc -l)"
echo ""

# Résumé final
echo "=== RÉSUMÉ ==="
echo "📁 Répertoire: $CURRENT_DIR"
echo "🐍 Python: $PYTHON_PATH"
echo "👤 Utilisateur: $(whoami)"
echo "📅 Planification: 1er de chaque mois à 8h00"
echo "📧 Logs: logs/sonarqube_report.log"
echo "📄 Rapports: reports/rapport_sonarqube_YYYYMM.pdf"
