#!/bin/bash

# Installation minimale pour environnements sans privilèges root
echo "=== Installation utilisateur (sans sudo) ==="

echo "⚠️  Ce script est pour les environnements où vous n'avez pas les droits sudo"
echo "Si vous avez les droits sudo, utilisez install_dependencies.sh à la place"
echo ""

# Vérification de Python 3
if command -v python3 >/dev/null 2>&1; then
    PYTHON_VERSION=$(python3 --version 2>&1)
    echo "✓ Python installé: $PYTHON_VERSION"
else
    echo "✗ Python 3 non trouvé. Contactez votre administrateur système."
    exit 1
fi

# Vérification de pip
if command -v pip3 >/dev/null 2>&1; then
    PIP_VERSION=$(pip3 --version 2>&1)
    echo "✓ Pip installé: $PIP_VERSION"
elif python3 -m pip --version >/dev/null 2>&1; then
    echo "✓ Pip disponible via python3 -m pip"
    alias pip3="python3 -m pip"
else
    echo "✗ Pip non trouvé. Contactez votre administrateur système."
    exit 1
fi

echo ""
echo "=== Installation des packages Python en mode utilisateur ==="

# Installation avec --user pour éviter les problèmes de permissions
PACKAGES=(
    "requests>=2.28.0"
    "pandas>=1.5.0"
    "reportlab>=3.6.0"
    "pillow>=9.0.0"
)

for package in "${PACKAGES[@]}"; do
    echo "Installation de $package..."
    if pip3 install --user "$package"; then
        echo "✓ $package installé avec succès"
    else
        echo "⚠️  Tentative avec python -m pip..."
        if python3 -m pip install --user "$package"; then
            echo "✓ $package installé avec succès"
        else
            echo "✗ Erreur lors de l'installation de $package"
            echo "Essayez manuellement: pip3 install --user $package"
        fi
    fi
done

echo ""
echo "=== Vérification des installations ==="

python3 -c "
import sys
print('Python path:', sys.path)
try:
    import requests
    print('✓ Requests version:', requests.__version__)
except ImportError as e:
    print('✗ Requests:', e)

try:
    import pandas
    print('✓ Pandas version:', pandas.__version__)
except ImportError as e:
    print('✗ Pandas:', e)

try:
    import reportlab
    print('✓ ReportLab version:', reportlab.Version)
except ImportError as e:
    print('✗ ReportLab:', e)

try:
    from PIL import Image
    print('✓ Pillow installé')
except ImportError as e:
    print('✗ Pillow:', e)

import configparser
import smtplib
import ssl
import json
import base64
import logging
import os
from datetime import datetime
from email.mime.multipart import MIMEMultipart
print('✓ Modules standard Python OK')
"

echo ""
echo "=== Configuration des permissions ==="

chmod +x sonarqube_monthly_report.py 2>/dev/null || echo "⚠️  sonarqube_monthly_report.py non trouvé dans le répertoire courant"
chmod +x test_config.py 2>/dev/null || echo "⚠️  test_config.py non trouvé dans le répertoire courant"
chmod 600 config.ini 2>/dev/null || echo "ℹ️  config.ini sera sécurisé après configuration"

echo ""
echo "=== Création des dossiers ==="
mkdir -p logs reports backup
echo "✓ Dossiers créés: logs/, reports/, backup/"

echo ""
echo "=== Installation utilisateur terminée! ==="
echo ""
echo "📋 Notes importantes:"
echo "• Les packages sont installés dans ~/.local/"
echo "• Assurez-vous que ~/.local/bin est dans votre PATH"
echo "• Pour cron, vous devrez peut-être utiliser le chemin complet vers python3"
echo ""
echo "📋 Prochaines étapes:"
echo "1. Configurez config.ini"
echo "2. Testez: python3 test_config.py"
echo "3. Testez: python3 sonarqube_monthly_report.py"
echo "4. Configurez crontab avec le chemin complet"
echo ""
echo "🔧 Si des modules ne sont pas trouvés, ajoutez à votre .bashrc:"
echo 'export PATH="$HOME/.local/bin:$PATH"'
echo 'export PYTHONPATH="$HOME/.local/lib/python3.x/site-packages:$PYTHONPATH"'
