#!/bin/bash

# Installation complète pour le script de rapport SonarQube
echo "=== Installation des prérequis système ==="

# Détection du système d'exploitation
if command -v apt-get >/dev/null 2>&1; then
    # Système basé sur Debian/Ubuntu
    echo "Système détecté: Debian/Ubuntu"
    
    # Mise à jour des paquets système
    echo "Mise à jour du système..."
    sudo apt-get update -y
    
    # Installation de Python 3 et pip si non présents
    echo "Installation de Python 3 et pip..."
    sudo apt-get install -y python3 python3-pip python3-dev python3-venv
    
    # Installation des dépendances système pour ReportLab (PDF)
    echo "Installation des dépendances système pour PDF..."
    sudo apt-get install -y build-essential libfreetype6-dev libjpeg-dev libpng-dev zlib1g-dev
    
    # Installation de cron si non présent
    echo "Installation de cron..."
    sudo apt-get install -y cron
    sudo systemctl enable cron
    sudo systemctl start cron
    
elif command -v yum >/dev/null 2>&1; then
    # Système basé sur RedHat/CentOS
    echo "Système détecté: RedHat/CentOS/Fedora"
    
    # Installation de Python 3 et pip
    echo "Installation de Python 3 et pip..."
    sudo yum install -y python3 python3-pip python3-devel
    
    # Installation des dépendances système
    echo "Installation des dépendances système..."
    sudo yum install -y gcc freetype-devel libjpeg-devel libpng-devel zlib-devel
    
    # Installation de cron
    echo "Installation de cron..."
    sudo yum install -y cronie
    sudo systemctl enable crond
    sudo systemctl start crond
    
elif command -v pacman >/dev/null 2>&1; then
    # Système Arch Linux
    echo "Système détecté: Arch Linux"
    
    # Installation de Python 3 et pip
    echo "Installation de Python 3 et pip..."
    sudo pacman -Sy --noconfirm python python-pip
    
    # Installation des dépendances système
    echo "Installation des dépendances système..."
    sudo pacman -S --noconfirm gcc freetype2 libjpeg-turbo libpng zlib
    
    # Installation de cron
    echo "Installation de cron..."
    sudo pacman -S --noconfirm cronie
    sudo systemctl enable cronie
    sudo systemctl start cronie
    
else
    echo "⚠️  Système d'exploitation non détecté automatiquement"
    echo "Veuillez installer manuellement:"
    echo "- Python 3 et pip"
    echo "- Bibliothèques de développement (gcc, freetype, libjpeg, libpng, zlib)"
    echo "- Service cron"
fi

echo ""
echo "=== Vérification de Python ==="

# Vérification de Python 3
if command -v python3 >/dev/null 2>&1; then
    PYTHON_VERSION=$(python3 --version 2>&1)
    echo "✓ Python installé: $PYTHON_VERSION"
else
    echo "✗ Python 3 non trouvé. Installation manuelle requise."
    exit 1
fi

# Vérification de pip
if command -v pip3 >/dev/null 2>&1; then
    PIP_VERSION=$(pip3 --version 2>&1)
    echo "✓ Pip installé: $PIP_VERSION"
else
    echo "✗ Pip non trouvé. Installation manuelle requise."
    exit 1
fi

echo ""
echo "=== Installation des dépendances Python ==="

# Mise à jour de pip
echo "Mise à jour de pip..."
python3 -m pip install --upgrade pip --break-system-packages 2>/dev/null || python3 -m pip install --upgrade pip

# Installation des packages requis avec gestion des erreurs
echo "Installation des packages Python..."

# Liste des packages avec versions spécifiques pour éviter les conflits
PACKAGES=(
    "requests>=2.28.0"
    "pandas>=1.5.0"
    "reportlab>=3.6.0"
    "configparser"  # Inclus dans Python 3+ mais ajouté pour compatibilité
    "pillow>=9.0.0"  # Requis pour ReportLab avec images
)

for package in "${PACKAGES[@]}"; do
    echo "Installation de $package..."
    if python3 -m pip install "$package" --break-system-packages 2>/dev/null; then
        echo "✓ $package installé avec succès"
    elif python3 -m pip install "$package"; then
        echo "✓ $package installé avec succès"
    else
        echo "✗ Erreur lors de l'installation de $package"
        exit 1
    fi
done

echo ""
echo "=== Vérification des installations ==="

# Test d'importation de tous les modules
echo "Test d'importation des modules Python..."
python3 -c "
import sys
import requests
import pandas
import reportlab
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate
import configparser
import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import json
import base64
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional

print('✓ Tous les modules Python sont importés correctement')
print(f'✓ Version Python: {sys.version.split()[0]}')
print(f'✓ Version Requests: {requests.__version__}')
print(f'✓ Version Pandas: {pandas.__version__}')
print(f'✓ Version ReportLab: {reportlab.Version}')
"

if [ $? -eq 0 ]; then
    echo "✓ Vérification réussie!"
else
    echo "✗ Erreur lors de la vérification des modules"
    exit 1
fi

echo ""
echo "=== Vérification du service cron ==="

# Vérification et démarrage de cron
if command -v systemctl >/dev/null 2>&1; then
    if systemctl is-active --quiet cron || systemctl is-active --quiet crond; then
        echo "✓ Service cron actif"
    else
        echo "⚠️  Tentative de démarrage du service cron..."
        sudo systemctl start cron 2>/dev/null || sudo systemctl start crond 2>/dev/null
        if systemctl is-active --quiet cron || systemctl is-active --quiet crond; then
            echo "✓ Service cron démarré"
        else
            echo "⚠️  Impossible de démarrer cron automatiquement. Démarrage manuel requis."
        fi
    fi
else
    echo "⚠️  Systemctl non disponible. Vérifiez manuellement que cron est actif."
fi

echo ""
echo "=== Configuration des permissions ==="

# Rendre les scripts exécutables
chmod +x sonarqube_monthly_report.py 2>/dev/null || echo "⚠️  sonarqube_monthly_report.py non trouvé"
chmod +x test_config.py 2>/dev/null || echo "⚠️  test_config.py non trouvé"

# Sécuriser le fichier de configuration
chmod 600 config.ini 2>/dev/null || echo "⚠️  config.ini non trouvé - sera créé lors de la configuration"

echo ""
echo "=== Création de l'environnement de travail ==="

# Création des dossiers nécessaires
mkdir -p logs
mkdir -p reports
mkdir -p backup

echo "✓ Dossiers créés: logs/, reports/, backup/"

echo ""
echo "=== Installation terminée! ==="
echo ""
echo "📋 Prochaines étapes:"
echo "1. Configurez le fichier config.ini avec vos paramètres"
echo "2. Testez la configuration: python3 test_config.py"
echo "3. Testez l'exécution: python3 sonarqube_monthly_report.py"
echo "4. Configurez le crontab: crontab crontab_config"
echo ""
echo "📖 Consultez README.md pour plus d'informations"

echo ""
echo "=== Informations système ==="
echo "OS: $(uname -s) $(uname -r)"
echo "Python: $(python3 --version 2>&1)"
echo "Pip: $(pip3 --version 2>&1)"
echo "Utilisateur: $(whoami)"
echo "Répertoire: $(pwd)"
echo ""
