#!/bin/bash

# Installation des dépendances pour le script de rapport SonarQube
echo "Installation des dépendances Python..."

# Mise à jour de pip
python3 -m pip install --upgrade pip

# Installation des packages requis
pip3 install requests pandas reportlab configparser

echo "Installation terminée!"

# Vérification de l'installation
echo "Vérification des packages installés:"
python3 -c "
import requests
import pandas
import reportlab
import configparser
print('✓ Tous les packages sont installés correctement')
"
