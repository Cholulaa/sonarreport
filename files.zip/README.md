# Guide d'Installation - Rapport Mensuel SonarQube

## Vue d'ensemble

Ce système génère automatiquement un rapport mensuel PDF de tous vos projets SonarQube et l'envoie par email le premier de chaque mois.

## Fonctionnalités

- ✅ Récupération automatique de tous les projets SonarQube
- ✅ Extraction des métriques clés (bugs, vulnérabilités, couverture, etc.)
- ✅ Génération d'un rapport PDF professionnel
- ✅ Envoi automatique par email
- ✅ Planification mensuelle via cron
- ✅ Logging complet des opérations

## Installation

### 1. Prérequis

```bash
# Vérifiez que Python 3 est installé
python3 --version

# Vérifiez que pip est installé
pip3 --version
```

### 2. Installation des dépendances

```bash
# Rendez le script d'installation exécutable
chmod +x install_dependencies.sh

# Exécutez l'installation
./install_dependencies.sh
```

### 3. Configuration

Éditez le fichier `config.ini` avec vos paramètres :

```ini
[sonarqube]
# URL de votre SonarQube (remplacez localhost par votre serveur)
url = http://your-sonarqube-server:9000

# Méthode 1: Token d'authentification (RECOMMANDÉ)
token = squ_1234567890abcdef1234567890abcdef12345678

# Méthode 2: Username/Password (moins sécurisé)
# username = your_username
# password = your_password

[email]
# Configuration SMTP (exemple pour Gmail)
smtp_server = smtp.gmail.com
smtp_port = 587

# Vos identifiants email
username = votre.email@gmail.com
password = votre_mot_de_passe_application

# Liste des destinataires (séparés par des virgules)
recipients = manager@company.com,lead@company.com

[report]
# Titre personnalisé du rapport
title = Rapport Qualité Code - Votre Société
```

#### 📝 Note sur l'authentification SonarQube

**Option 1 - Token (Recommandée):**
1. Connectez-vous à SonarQube
2. Allez dans My Account > Security
3. Générez un nouveau token
4. Copiez le token dans le fichier config.ini

**Option 2 - Username/Password:**
- Utilisez vos identifiants SonarQube habituels

#### 📧 Configuration Email Gmail

Si vous utilisez Gmail, vous devez :
1. Activer l'authentification à 2 facteurs
2. Générer un "Mot de passe d'application"
3. Utiliser ce mot de passe dans le fichier config.ini

### 4. Test de configuration

```bash
# Testez votre configuration
python3 test_config.py
```

Le script vérifiera :
- ✅ Connexion à SonarQube
- ✅ Récupération des projets
- ✅ Configuration SMTP

### 5. Test d'exécution

```bash
# Test manuel du script complet
python3 sonarqube_monthly_report.py
```

Cela génèrera un rapport et l'enverra immédiatement.

## Configuration du Cron

### Installation du crontab

```bash
# Éditez le fichier crontab_config avec le bon chemin
nano crontab_config

# Modifiez la ligne :
# 0 8 1 * * cd /path/to/your/script && /usr/bin/python3 sonarqube_monthly_report.py >> sonarqube_report.log 2>&1

# Remplacez /path/to/your/script par le chemin réel, par exemple :
# 0 8 1 * * cd /home/user/sonarqube-reporter && /usr/bin/python3 sonarqube_monthly_report.py >> sonarqube_report.log 2>&1
```

### Ajout au crontab

```bash
# Sauvegardez le crontab actuel (optionnel)
crontab -l > crontab_backup.txt

# Ajoutez la nouvelle tâche
crontab crontab_config

# Vérifiez que la tâche est bien ajoutée
crontab -l
```

### Planifications alternatives

```bash
# Tous les 1er du mois à 8h00
0 8 1 * * 

# Tous les 1er du mois à 9h30
30 9 1 * *

# Tous les lundis à 8h00 (pour test)
0 8 * * 1

# Tous les jours à 14h30 (pour test - à supprimer après)
30 14 * * *
```

## Structure des fichiers

```
votre-dossier/
├── sonarqube_monthly_report.py    # Script principal
├── config.ini                     # Configuration
├── test_config.py                 # Script de test
├── install_dependencies.sh        # Installation des dépendances
├── crontab_config                 # Configuration cron
├── README.md                      # Cette documentation
├── sonarqube_report.log           # Logs d'exécution (généré automatiquement)
└── rapport_sonarqube_YYYYMM.pdf   # Rapports générés (générés automatiquement)
```

## Contenu du rapport

Le rapport PDF contient :

### Résumé Exécutif
- Nombre total de projets
- Lignes de code totales
- Bugs, vulnérabilités, code smells
- Couverture de tests moyenne
- Projets avec problèmes

### Détails par Projet
- Nom du projet
- Métriques de qualité
- Notes de qualité (A, B, C, D, E)
- Couverture de tests

## Dépannage

### Erreur de connexion SonarQube

```bash
# Vérifiez l'URL
curl http://your-sonarqube:9000/api/system/status

# Vérifiez le token
curl -u "your_token:" http://your-sonarqube:9000/api/projects/search
```

### Erreur d'envoi email

```bash
# Testez la connexion SMTP
python3 -c "
import smtplib
import ssl
context = ssl.create_default_context()
with smtplib.SMTP('smtp.gmail.com', 587) as server:
    server.starttls(context=context)
    print('Connexion SMTP OK')
"
```

### Vérification des logs

```bash
# Consultez les logs d'exécution
tail -f sonarqube_report.log

# Logs du cron
tail -f /var/log/syslog | grep CRON
```

### Permissions

```bash
# Assurez-vous que le script est exécutable
chmod +x sonarqube_monthly_report.py

# Vérifiez les permissions du dossier
ls -la
```

## Personnalisation

### Métriques supplémentaires

Modifiez la liste `metrics` dans la fonction `get_project_metrics()` :

```python
metrics = [
    'ncloc', 'lines', 'files', 'functions', 'classes',
    'bugs', 'vulnerabilities', 'code_smells',
    'coverage', 'duplicated_lines_density',
    'sqale_rating', 'reliability_rating', 'security_rating',
    'complexity', 'cognitive_complexity',
    # Ajoutez d'autres métriques ici
    'technical_debt', 'sqale_index'
]
```

### Format du rapport

Modifiez la fonction `create_pdf_report()` pour personnaliser :
- Couleurs
- Mise en page
- Métriques affichées
- Graphiques (avec matplotlib)

### Fréquence d'envoi

Modifiez le crontab pour d'autres fréquences :
- Hebdomadaire : `0 8 * * 1` (tous les lundis)
- Bi-mensuel : `0 8 1,15 * *` (1er et 15 du mois)

## Sécurité

- ✅ Utilisez des tokens plutôt que des mots de passe
- ✅ Limitez les permissions du fichier config.ini
- ✅ Utilisez des mots de passe d'application pour Gmail
- ✅ Surveillez les logs régulièrement

```bash
# Sécurisez le fichier de configuration
chmod 600 config.ini
```

## Support

En cas de problème :

1. Vérifiez les logs : `cat sonarqube_report.log`
2. Testez la configuration : `python3 test_config.py`
3. Vérifiez les métriques SonarQube disponibles dans l'API
4. Consultez la documentation SonarQube API

## API SonarQube

Documentation officielle : https://docs.sonarqube.org/latest/extend/web-api/

Points d'API utilisés :
- `/api/projects/search` - Liste des projets
- `/api/measures/component` - Métriques des projets
- `/api/issues/search` - Issues des projets
