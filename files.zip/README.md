# Guide d'Installation - Rapport Mensuel SonarQube CSI

## 🏢 Environnement CSI
- **Serveur**: `csi-sec-snq-cli-dev-01`
- **Utilisateur**: `scsq-devops`
- **Répertoire**: `/home/scsq-devops/reporting/sonarreport`

## 🚀 Démarrage rapide pour scsq-devops

```bash
# Vous êtes dans: /home/scsq-devops/reporting/sonarreport

# 1. Déploiement automatique complet
./deploy_scsq_devops.sh

# OU étape par étape:

# 1. Diagnostic de l'environnement
python3 system_check.py

# 2. Installation automatique
./install_dependencies.sh      # Avec sudo
# OU
./install_dependencies_user.sh  # Sans sudo

# 3. Configuration
nano config.ini  # Éditez avec vos paramètres CSI

# 4. Test de configuration
python3 test_config.py

# 5. Test d'exécution
python3 sonarqube_monthly_report.py

# 6. Installation cron
crontab crontab_config
```

## Vue d'ensemble

Ce système génère automatiquement un rapport mensuel PDF de tous vos projets SonarQube et l'envoie par email le premier de chaque mois.

## Fonctionnalités

- ✅ Récupération automatique de tous les projets SonarQube
- ✅ Extraction des métriques clés (bugs, vulnérabilités, couverture, etc.)
- ✅ Génération d'un rapport PDF professionnel
- ✅ Envoi automatique par email
- ✅ Planification mensuelle via cron
- ✅ Logging complet des opérations

## Installation

### 1. Diagnostic système (RECOMMANDÉ)

```bash
# Vérifiez d'abord votre environnement
python3 system_check.py
```

Ce script vérifiera automatiquement :
- ✅ Version de Python et modules requis
- ✅ Outils système (cron, curl, etc.)
- ✅ Connectivité réseau
- ✅ Permissions des fichiers
- ✅ Recommandations d'installation spécifiques

### 2. Installation automatique

**Option A - Installation complète (avec sudo) :**
```bash
# Pour les serveurs où vous avez les droits administrateur
chmod +x install_dependencies.sh
./install_dependencies.sh
```

**Option B - Installation utilisateur (sans sudo) :**
```bash
# Pour les environnements restreints ou partagés
chmod +x install_dependencies_user.sh
./install_dependencies_user.sh
```

Le script d'installation complète installe automatiquement :
- ✅ Python 3 et pip (si non présents)
- ✅ Dépendances système (gcc, freetype, libjpeg, etc.)
- ✅ Service cron
- ✅ Tous les modules Python requis
- ✅ Configuration des permissions
- ✅ Création des dossiers de travail

### 3. Prérequis manuels (si scripts d'installation non utilisables)

Si les scripts automatiques ne fonctionnent pas dans votre environnement :

```bash
# Installation des modules Python uniquement
pip3 install --user requests pandas reportlab pillow

# OU avec les privilèges système
sudo pip3 install requests pandas reportlab pillow
```

### 3. Configuration pour l'environnement CSI

Éditez le fichier `config.ini` avec vos paramètres :

```ini
[sonarqube]
# URL de votre SonarQube CSI (adaptez l'URL selon votre configuration)
url = http://csi-sec-snq-cli-dev-01:9000

# Token d'authentification SonarQube (RECOMMANDÉ)
token = squ_1234567890abcdef1234567890abcdef12345678

[email]
# Configuration SMTP CSI (adaptez selon votre infrastructure email)
smtp_server = smtp.company.com
smtp_port = 587

# Votre email CSI
username = scsq-devops@company.com
password = votre_mot_de_passe_email

# Destinataires du rapport
recipients = security-team@company.com,devops-team@company.com

[report]
title = Rapport Qualité Code CSI - SonarQube
```

#### 📝 Note sur l'authentification SonarQube

**Option 1 - Token (Recommandée):**
1. Connectez-vous à SonarQube
2. Allez dans My Account > Security
3. Générez un nouveau token
4. Copiez le token dans le fichier config.ini

**Option 2 - Username/Password:**
- Utilisez vos identifiants SonarQube habituels

#### 📧 Configuration Email Gmail

Si vous utilisez Gmail, vous devez :
1. Activer l'authentification à 2 facteurs
2. Générer un "Mot de passe d'application"
3. Utiliser ce mot de passe dans le fichier config.ini

### 4. Test de configuration

```bash
# Testez votre configuration
python3 test_config.py
```

Le script vérifiera :
- ✅ Connexion à SonarQube
- ✅ Récupération des projets
- ✅ Configuration SMTP

### 5. Test d'exécution

```bash
# Test manuel du script complet
python3 sonarqube_monthly_report.py
```

Cela génèrera un rapport et l'enverra immédiatement.

## Configuration du Cron

### Installation du crontab

```bash
# Éditez le fichier crontab_config avec le bon chemin
nano crontab_config

# Modifiez la ligne :
# 0 8 1 * * cd /path/to/your/script && /usr/bin/python3 sonarqube_monthly_report.py >> sonarqube_report.log 2>&1

# Remplacez /path/to/your/script par le chemin réel, par exemple :
# 0 8 1 * * cd /home/user/sonarqube-reporter && /usr/bin/python3 sonarqube_monthly_report.py >> sonarqube_report.log 2>&1
```

### Ajout au crontab

```bash
# Sauvegardez le crontab actuel (optionnel)
crontab -l > crontab_backup.txt

# Ajoutez la nouvelle tâche
crontab crontab_config

# Vérifiez que la tâche est bien ajoutée
crontab -l
```

### Planifications alternatives

```bash
# Tous les 1er du mois à 8h00
0 8 1 * * 

# Tous les 1er du mois à 9h30
30 9 1 * *

# Tous les lundis à 8h00 (pour test)
0 8 * * 1

# Tous les jours à 14h30 (pour test - à supprimer après)
30 14 * * *
```

## Structure des fichiers

```
/home/scsq-devops/reporting/sonarreport/
├── sonarqube_monthly_report.py    # Script principal
├── config.ini                     # Configuration CSI
├── test_config.py                 # Script de test
├── system_check.py                # Diagnostic système
├── deploy_scsq_devops.sh          # Script de déploiement CSI
├── install_dependencies.sh        # Installation complète (avec sudo)
├── install_dependencies_user.sh   # Installation utilisateur (sans sudo)
├── crontab_config                 # Configuration cron adaptée
├── README.md                      # Cette documentation
├── logs/                          # Logs d'exécution (créé automatiquement)
│   ├── sonarqube_report.log       # Logs production
│   ├── sonarqube_report_test.log  # Logs de test
│   └── sonarqube_report_weekly.log # Logs validation hebdomadaire
├── reports/                       # Rapports générés (créé automatiquement)
│   └── rapport_sonarqube_YYYYMM.pdf # Rapports mensuels
└── backup/                        # Sauvegardes (créé automatiquement)
```

## Contenu du rapport

Le rapport PDF contient :

### Résumé Exécutif
- Nombre total de projets
- Lignes de code totales
- Bugs, vulnérabilités, code smells
- Couverture de tests moyenne
- Projets avec problèmes

### Détails par Projet
- Nom du projet
- Métriques de qualité
- Notes de qualité (A, B, C, D, E)
- Couverture de tests

## Dépannage

### Diagnostic automatique

```bash
# Diagnostic complet de l'environnement
python3 system_check.py

# Vérification de la configuration SonarQube et email
python3 test_config.py
```

### Problèmes d'installation

**Modules Python manquants :**
```bash
# Réinstallez avec le script approprié
./install_dependencies.sh          # Avec sudo
# OU
./install_dependencies_user.sh     # Sans sudo

# Installation manuelle
pip3 install --user requests pandas reportlab pillow
```

**Erreur "Python.h not found" :**
```bash
# Ubuntu/Debian
sudo apt-get install python3-dev build-essential

# CentOS/RHEL
sudo yum install python3-devel gcc

# Ou utilisez le script d'installation complet
./install_dependencies.sh
```

### Erreur de connexion SonarQube

```bash
# Vérifiez l'URL
curl http://your-sonarqube:9000/api/system/status

# Vérifiez le token
curl -u "your_token:" http://your-sonarqube:9000/api/projects/search
```

### Erreur d'envoi email

```bash
# Testez la connexion SMTP
python3 -c "
import smtplib
import ssl
context = ssl.create_default_context()
with smtplib.SMTP('smtp.gmail.com', 587) as server:
    server.starttls(context=context)
    print('Connexion SMTP OK')
"
```

### Vérification des logs

```bash
# Consultez les logs d'exécution
tail -f logs/sonarqube_report.log

# Logs du cron
tail -f /var/log/syslog | grep CRON

# Logs de test
tail -f logs/sonarqube_report_test.log
```

### Permissions

```bash
# Assurez-vous que le script est exécutable
chmod +x sonarqube_monthly_report.py

# Vérifiez les permissions du dossier
ls -la
```

## Personnalisation

### Métriques supplémentaires

Modifiez la liste `metrics` dans la fonction `get_project_metrics()` :

```python
metrics = [
    'ncloc', 'lines', 'files', 'functions', 'classes',
    'bugs', 'vulnerabilities', 'code_smells',
    'coverage', 'duplicated_lines_density',
    'sqale_rating', 'reliability_rating', 'security_rating',
    'complexity', 'cognitive_complexity',
    # Ajoutez d'autres métriques ici
    'technical_debt', 'sqale_index'
]
```

### Format du rapport

Modifiez la fonction `create_pdf_report()` pour personnaliser :
- Couleurs
- Mise en page
- Métriques affichées
- Graphiques (avec matplotlib)

### Fréquence d'envoi

Modifiez le crontab pour d'autres fréquences :
- Hebdomadaire : `0 8 * * 1` (tous les lundis)
- Bi-mensuel : `0 8 1,15 * *` (1er et 15 du mois)

## Sécurité

- ✅ Utilisez des tokens plutôt que des mots de passe
- ✅ Limitez les permissions du fichier config.ini
- ✅ Utilisez des mots de passe d'application pour Gmail
- ✅ Surveillez les logs régulièrement

```bash
# Sécurisez le fichier de configuration
chmod 600 config.ini
```

## Support

En cas de problème :

1. Vérifiez les logs : `cat sonarqube_report.log`
2. Testez la configuration : `python3 test_config.py`
3. Vérifiez les métriques SonarQube disponibles dans l'API
4. Consultez la documentation SonarQube API

## API SonarQube

Documentation officielle : https://docs.sonarqube.org/latest/extend/web-api/

Points d'API utilisés :
- `/api/projects/search` - Liste des projets
- `/api/measures/component` - Métriques des projets
- `/api/issues/search` - Issues des projets
