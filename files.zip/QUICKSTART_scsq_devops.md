# Guide de Démarrage Rapide - scsq-devops

## 📍 Votre environnement
- **Serveur**: `csi-sec-snq-cli-dev-01`
- **Utilisateur**: `scsq-devops`  
- **Répertoire**: `/home/scsq-devops/reporting/sonarreport`

## 🚀 Installation en 1 commande

```bash
# Déploiement automatique complet
./deploy_scsq_devops.sh
```

## ⚙️ Configuration manuelle

### 1. Éditez config.ini
```bash
nano config.ini
```

**Configuration minimale requise :**
```ini
[sonarqube]
url = http://csi-sec-snq-cli-dev-01:9000
token = votre_token_sonarqube

[email]
smtp_server = smtp.company.com
username = scsq-devops@company.com
password = votre_mot_de_passe
recipients = security-team@company.com,manager@company.com
```

### 2. Test de la configuration
```bash
python3 test_config.py
```

### 3. Test d'exécution
```bash
python3 sonarqube_monthly_report.py
```

### 4. Installation du cron (mensuel)
```bash
crontab crontab_config
crontab -l  # Vérification
```

## 🔧 Commandes utiles

```bash
# Diagnostic système
python3 system_check.py

# Logs en temps réel
tail -f logs/sonarqube_report.log

# Voir les rapports générés
ls -la reports/

# Test manuel immédiat
python3 sonarqube_monthly_report.py

# Vérifier le cron actif
crontab -l | grep sonarqube
```

## 📊 Planification

**Production (défaut) :**
- 🗓️ **1er de chaque mois à 8h00**
- 📧 **Envoi automatique par email**
- 📄 **Rapport PDF dans reports/**

**Options de test disponibles :**
```bash
# Test hebdomadaire (vendredis 16h)
# 0 16 * * 5

# Test le 15 du mois (validation)  
# 0 14 15 * *

# Test quotidien (développement)
# 0 17 * * *
```

## 🆘 Dépannage rapide

**Problème de modules Python :**
```bash
./install_dependencies.sh
```

**Problème de connexion SonarQube :**
```bash
curl http://csi-sec-snq-cli-dev-01:9000/api/system/status
```

**Problème d'email :**
```bash
# Testez votre config SMTP
python3 -c "
import smtplib, ssl
context = ssl.create_default_context()
with smtplib.SMTP('smtp.company.com', 587) as server:
    server.starttls(context=context)
    print('SMTP OK')
"
```

## 📝 Logs importants

```bash
# Logs du script
tail -f logs/sonarqube_report.log

# Logs système pour cron
sudo tail -f /var/log/syslog | grep CRON

# Historique des rapports
ls -lat reports/
```

## ✅ Vérification finale

Après installation, vérifiez que tout fonctionne :

1. ✅ `python3 test_config.py` → OK
2. ✅ `python3 sonarqube_monthly_report.py` → Rapport généré
3. ✅ `crontab -l` → Tâche planifiée visible
4. ✅ `ls reports/` → PDF créé
5. ✅ Réception email → Email bien reçu

**🎯 Votre système est opérationnel !**

Le rapport sera automatiquement généré et envoyé le **1er de chaque mois à 8h00**.
