#!/usr/bin/env python3
"""
Script de test pour vérifier la configuration SonarQube
"""

import requests
import configparser
import sys

def test_sonarqube_connection():
    """Test la connexion à SonarQube."""
    print("Test de connexion SonarQube...")
    
    config = configparser.ConfigParser()
    config.read('config.ini')
    
    try:
        sonar_url = config.get('sonarqube', 'url')
        sonar_token = config.get('sonarqube', 'token', fallback=None)
        sonar_user = config.get('sonarqube', 'username', fallback=None)
        sonar_password = config.get('sonarqube', 'password', fallback=None)
        
        if sonar_token:
            auth = (sonar_token, '')
        else:
            auth = (sonar_user, sonar_password)
        
        # Test de l'API
        response = requests.get(f"{sonar_url}/api/system/status", auth=auth)
        response.raise_for_status()
        
        data = response.json()
        print(f"✓ Connexion réussie à SonarQube")
        print(f"  Status: {data.get('status')}")
        print(f"  Version: {data.get('version')}")
        
        # Test des projets
        response = requests.get(f"{sonar_url}/api/projects/search", auth=auth)
        response.raise_for_status()
        
        projects = response.json()
        print(f"✓ {len(projects.get('components', []))} projets trouvés")
        
        return True
        
    except Exception as e:
        print(f"✗ Erreur de connexion: {e}")
        return False

def test_email_config():
    """Test la configuration email CSI."""
    print("\nTest de configuration email CSI...")
    
    config = configparser.ConfigParser()
    config.read('config.ini')
    
    try:
        smtp_server = config.get('email', 'smtp_server')
        smtp_port = config.getint('email', 'smtp_port')
        email_sender = config.get('email', 'sender_email')
        recipients = config.get('email', 'recipients')
        
        print(f"✓ Serveur SMTP CSI: {smtp_server}:{smtp_port}")
        print(f"✓ Expéditeur: {email_sender}")
        print(f"✓ Destinataires: {recipients}")
        
        # Test de connexion SMTP CSI (sans authentification)
        import smtplib
        
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            # Pas d'authentification requise pour SMTP CSI interne
            print("✓ Connexion SMTP CSI réussie (pas d'authentification requise)")
        
        return True
        
    except Exception as e:
        print(f"✗ Erreur de configuration email CSI: {e}")
        return False

def main():
    """Point d'entrée principal."""
    print("=== Test de configuration SonarQube Reporter ===\n")
    
    sonar_ok = test_sonarqube_connection()
    email_ok = test_email_config()
    
    print(f"\n=== Résumé ===")
    print(f"SonarQube: {'✓ OK' if sonar_ok else '✗ ERREUR'}")
    print(f"Email: {'✓ OK' if email_ok else '✗ ERREUR'}")
    
    if sonar_ok and email_ok:
        print("\n✓ Configuration valide - Le script peut être exécuté")
        return 0
    else:
        print("\n✗ Veuillez corriger les erreurs de configuration")
        return 1

if __name__ == "__main__":
    exit(main())
