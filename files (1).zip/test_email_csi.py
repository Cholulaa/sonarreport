#!/usr/bin/env python3
"""
Script de test d'envoi d'email pour la configuration CSI
Teste l'envoi d'email via le serveur SMTP CSI sans authentification
"""

import smtplib
import configparser
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def test_email_csi():
    """Test d'envoi d'email avec la configuration CSI."""
    print("=== Test d'envoi d'email CSI ===")
    
    # Lecture de la configuration
    config = configparser.ConfigParser()
    try:
        config.read('config.ini')
        
        smtp_server = config.get('email', 'smtp_server')
        smtp_port = config.getint('email', 'smtp_port')
        sender_email = config.get('email', 'sender_email')
        recipients = config.get('email', 'recipients').split(',')
        
        print(f"Serveur SMTP: {smtp_server}:{smtp_port}")
        print(f"Expéditeur: {sender_email}")
        print(f"Destinataires: {', '.join(recipients)}")
        
    except Exception as e:
        print(f"❌ Erreur de lecture de config.ini: {e}")
        return False
    
    # Création du message de test
    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = ', '.join(recipients)
        msg['Subject'] = "[TEST CSI] Test du système de rapport SonarQube"
        
        # Corps de l'email de test
        body = f"""
Bonjour,

Ceci est un email de test pour vérifier la configuration du système de rapport SonarQube CSI.

Informations du test:
- Date: {datetime.now().strftime('%d/%m/%Y à %H:%M:%S')}
- Serveur SMTP: {smtp_server}:{smtp_port}
- Configuration: SMTP interne CSI (sans authentification)

Si vous recevez cet email, la configuration est correcte et le rapport mensuel pourra être envoyé automatiquement.

Cordialement,
Système de test SonarQube CSI
"""
        
        msg.attach(MIMEText(body, 'plain', 'utf-8'))
        
        # Envoi via SMTP CSI
        print("\n🔄 Tentative d'envoi...")
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            # Pas d'authentification pour SMTP CSI interne
            server.sendmail(sender_email, recipients, msg.as_string())
        
        print("✅ Email de test envoyé avec succès !")
        print(f"   → Vérifiez la réception sur: {', '.join(recipients)}")
        return True
        
    except Exception as e:
        print(f"❌ Erreur lors de l'envoi: {e}")
        return False

def test_smtp_connection():
    """Test simple de connexion SMTP."""
    print("\n=== Test de connexion SMTP ===")
    
    config = configparser.ConfigParser()
    config.read('config.ini')
    
    try:
        smtp_server = config.get('email', 'smtp_server')
        smtp_port = config.getint('email', 'smtp_port')
        
        print(f"Test de connexion à {smtp_server}:{smtp_port}")
        
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            # Test de connexion basique
            status = server.noop()
            print(f"✅ Connexion SMTP réussie (Status: {status})")
            return True
            
    except Exception as e:
        print(f"❌ Erreur de connexion SMTP: {e}")
        return False

def main():
    """Point d'entrée principal."""
    print("🧪 TEST EMAIL CSI - Système de rapport SonarQube")
    print("=" * 55)
    
    # Test de connexion
    connection_ok = test_smtp_connection()
    
    if connection_ok:
        print("\n" + "=" * 55)
        response = input("La connexion SMTP fonctionne. Voulez-vous envoyer un email de test ? (y/N): ")
        
        if response.lower() in ['y', 'yes', 'oui', 'o']:
            email_ok = test_email_csi()
            
            if email_ok:
                print("\n🎉 Test complet réussi !")
                print("   Le système de rapport SonarQube est prêt à fonctionner.")
            else:
                print("\n⚠️  Erreur lors du test d'email")
                
        else:
            print("Test d'envoi annulé.")
    else:
        print("\n❌ Impossible de se connecter au serveur SMTP")
        print("   Vérifiez la configuration réseau et le fichier config.ini")
    
    print("\n" + "=" * 55)

if __name__ == "__main__":
    main()
