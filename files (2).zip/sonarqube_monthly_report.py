#!/usr/bin/env python3
"""
SonarQube Monthly Report Generator - Version Exhaustive
Point d'entrée principal pour les rapports exhaustifs SonarQube
"""

import sys
import os

# Redirection vers le script exhaustif
print("🚀 Lancement du générateur de rapports exhaustifs SonarQube...")
print("📊 Génération d'un rapport détaillé par projet + synthèse globale")
print("=" * 60)

# Import et exécution du script exhaustif
try:
    from sonarqube_comprehensive_report import main
    exit_code = main()
    sys.exit(exit_code)
except ImportError as e:
    print(f"❌ Erreur d'import: {e}")
    print("Veuillez vous assurer que tous les modules sont installés.")
    print("Exécutez: ./install_dependencies.sh")
    sys.exit(1)
except Exception as e:
    print(f"❌ Erreur fatale: {e}")
    sys.exit(1)
