#!/usr/bin/env python3
"""
SonarQube Comprehensive Report Generator
Génère des rapports exhaustifs par projet + rapport de synthèse
Version: 2.0 - Rapports exhaustifs pour développeurs
"""

import requests
import json
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus.flowables import HRFlowable
import base64
import logging
import os
from typing import Dict, List, Optional, Tuple
import configparser
import zipfile
from collections import defaultdict

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class SonarQubeComprehensiveReporter:
    def __init__(self, config_file: str = 'config.ini'):
        """Initialise le générateur de rapports SonarQube exhaustifs."""
        self.config = configparser.ConfigParser()
        self.config.read(config_file)
        
        # Configuration SonarQube
        self.sonar_url = self.config.get('sonarqube', 'url')
        self.sonar_token = self.config.get('sonarqube', 'token', fallback=None)
        self.sonar_user = self.config.get('sonarqube', 'username', fallback=None)
        self.sonar_password = self.config.get('sonarqube', 'password', fallback=None)
        
        # Configuration Email CSI
        self.smtp_server = self.config.get('email', 'smtp_server')
        self.smtp_port = self.config.getint('email', 'smtp_port')
        self.email_sender = self.config.get('email', 'sender_email')
        self.recipients = self.config.get('email', 'recipients').split(',')
        
        # Configuration du rapport
        self.report_title = self.config.get('report', 'title', fallback='Rapports Exhaustifs SonarQube CSI')
        self.company_name = self.config.get('report', 'company_name', fallback='CSI Security')
        self.department = self.config.get('report', 'department', fallback='DevSecOps')
        
        # Headers pour les requêtes API
        self.headers = {'Content-Type': 'application/json'}
        if self.sonar_token:
            self.auth = (self.sonar_token, '')
        else:
            self.auth = (self.sonar_user, self.sonar_password)

    def get_projects(self) -> List[Dict]:
        """Récupère la liste de tous les projets SonarQube."""
        try:
            url = f"{self.sonar_url}/api/projects/search"
            response = requests.get(url, auth=self.auth, headers=self.headers)
            response.raise_for_status()
            
            data = response.json()
            projects = data.get('components', [])
            logger.info(f"Trouvé {len(projects)} projets")
            return projects
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des projets: {e}")
            return []

    def get_project_comprehensive_metrics(self, project_key: str) -> Dict:
        """Récupère TOUTES les métriques disponibles d'un projet."""
        # Métriques exhaustives pour les développeurs
        metrics = [
            # Taille du code
            'ncloc', 'lines', 'files', 'functions', 'classes', 'statements',
            
            # Qualité générale
            'bugs', 'vulnerabilities', 'code_smells', 'sqale_index', 'sqale_rating',
            'reliability_rating', 'security_rating', 'security_hotspots',
            
            # Couverture de tests
            'coverage', 'line_coverage', 'branch_coverage', 'uncovered_lines',
            'uncovered_conditions', 'tests', 'test_errors', 'test_failures',
            'test_execution_time',
            
            # Duplication
            'duplicated_lines', 'duplicated_blocks', 'duplicated_files',
            'duplicated_lines_density',
            
            # Complexité
            'complexity', 'cognitive_complexity', 'complexity_in_classes',
            'complexity_in_functions',
            
            # Dette technique
            'sqale_debt_ratio', 'effort_to_reach_maintainability_rating_a',
            
            # Maintenabilité
            'maintainability_rating', 'technical_debt',
            
            # Documentation
            'comment_lines', 'comment_lines_density', 'public_documented_api_density',
            'public_undocumented_api',
            
            # Violations par sévérité
            'violations', 'blocker_violations', 'critical_violations',
            'major_violations', 'minor_violations', 'info_violations'
        ]
        
        try:
            url = f"{self.sonar_url}/api/measures/component"
            params = {
                'component': project_key,
                'metricKeys': ','.join(metrics)
            }
            
            response = requests.get(url, auth=self.auth, headers=self.headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            component = data.get('component', {})
            measures = component.get('measures', [])
            
            # Organise les métriques en dictionnaire
            metrics_dict = {
                'project_key': project_key,
                'project_name': component.get('name', project_key),
                'last_analysis_date': component.get('analysisDate', 'N/A')
            }
            
            for measure in measures:
                metric_key = measure.get('metric')
                value = measure.get('value', '0')
                metrics_dict[metric_key] = value
            
            return metrics_dict
            
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des métriques pour {project_key}: {e}")
            return {'project_key': project_key, 'project_name': project_key}

    def get_project_issues_detailed(self, project_key: str) -> Dict:
        """Récupère les issues détaillées d'un projet avec localisation."""
        try:
            issues = []
            page = 1
            page_size = 500
            
            while True:
                url = f"{self.sonar_url}/api/issues/search"
                params = {
                    'componentKeys': project_key,
                    'resolved': 'false',
                    'ps': page_size,
                    'p': page,
                    'additionalFields': 'comments',
                    's': 'SEVERITY,FILE_LINE'  # Tri par sévérité puis par fichier/ligne
                }
                
                response = requests.get(url, auth=self.auth, headers=self.headers, params=params)
                response.raise_for_status()
                
                data = response.json()
                page_issues = data.get('issues', [])
                
                if not page_issues:
                    break
                
                for issue in page_issues:
                    issue_detail = {
                        'key': issue.get('key'),
                        'rule': issue.get('rule'),
                        'severity': issue.get('severity'),
                        'type': issue.get('type'),
                        'component': issue.get('component', '').replace(project_key + ':', ''),
                        'line': issue.get('line', 'N/A'),
                        'message': issue.get('message', ''),
                        'author': issue.get('author', 'N/A'),
                        'creationDate': issue.get('creationDate', ''),
                        'effort': issue.get('effort', 'N/A'),
                        'debt': issue.get('debt', 'N/A'),
                        'status': issue.get('status', ''),
                        'resolution': issue.get('resolution', ''),
                        'tags': ','.join(issue.get('tags', []))
                    }
                    issues.append(issue_detail)
                
                if len(page_issues) < page_size:
                    break
                
                page += 1
            
            # Statistiques par sévérité et type
            severity_stats = defaultdict(int)
            type_stats = defaultdict(int)
            file_stats = defaultdict(int)
            
            for issue in issues:
                severity_stats[issue['severity']] += 1
                type_stats[issue['type']] += 1
                file_stats[issue['component']] += 1
            
            return {
                'total_issues': len(issues),
                'issues': issues,
                'by_severity': dict(severity_stats),
                'by_type': dict(type_stats),
                'by_file': dict(file_stats),
                'most_problematic_files': sorted(file_stats.items(), key=lambda x: x[1], reverse=True)[:10]
            }
            
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des issues pour {project_key}: {e}")
            return {'total_issues': 0, 'issues': [], 'by_severity': {}, 'by_type': {}, 'by_file': {}}

    def get_project_hotspots(self, project_key: str) -> List[Dict]:
        """Récupère les security hotspots du projet."""
        try:
            url = f"{self.sonar_url}/api/hotspots/search"
            params = {
                'projectKey': project_key,
                'status': 'TO_REVIEW',
                'ps': 500
            }
            
            response = requests.get(url, auth=self.auth, headers=self.headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            hotspots = []
            
            for hotspot in data.get('hotspots', []):
                hotspot_detail = {
                    'key': hotspot.get('key'),
                    'rule': hotspot.get('rule'),
                    'component': hotspot.get('component', '').replace(project_key + ':', ''),
                    'line': hotspot.get('line', 'N/A'),
                    'message': hotspot.get('message', ''),
                    'author': hotspot.get('author', 'N/A'),
                    'creationDate': hotspot.get('creationDate', ''),
                    'status': hotspot.get('status', ''),
                    'vulnerabilityProbability': hotspot.get('vulnerabilityProbability', 'LOW')
                }
                hotspots.append(hotspot_detail)
            
            return hotspots
            
        except requests.RequestException as e:
            logger.error(f"Erreur lors de la récupération des hotspots pour {project_key}: {e}")
            return []

    def create_project_comprehensive_report(self, project_data: Dict, issues_data: Dict, 
                                          hotspots: List[Dict], filename: str):
        """Crée un rapport PDF exhaustif pour un projet."""
        doc = SimpleDocTemplate(filename, pagesize=A4, 
                              leftMargin=50, rightMargin=50, topMargin=50, bottomMargin=50)
        elements = []
        styles = getSampleStyleSheet()
        
        # Styles personnalisés
        title_style = ParagraphStyle(
            'ProjectTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            textColor=colors.darkblue,
            alignment=1
        )
        
        section_style = ParagraphStyle(
            'SectionHeader',
            parent=styles['Heading2'],
            fontSize=14,
            spaceBefore=20,
            spaceAfter=10,
            textColor=colors.darkgreen
        )
        
        subsection_style = ParagraphStyle(
            'SubsectionHeader',
            parent=styles['Heading3'],
            fontSize=12,
            spaceBefore=15,
            spaceAfter=8,
            textColor=colors.darkred
        )
        
        # En-tête du rapport
        project_name = project_data.get('project_name', 'Projet Inconnu')
        title = Paragraph(f"Rapport Exhaustif de Qualité<br/>{project_name}", title_style)
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Informations générales
        info_data = [
            ['Informations Générales', ''],
            ['Nom du projet', project_name],
            ['Clé du projet', project_data.get('project_key', 'N/A')],
            ['Dernière analyse', project_data.get('last_analysis_date', 'N/A')],
            ['Date de génération', datetime.now().strftime('%d/%m/%Y à %H:%M')],
            ['Généré par', f"{self.company_name} - {self.department}"]
        ]
        
        info_table = Table(info_data, colWidths=[3*inch, 3*inch])
        info_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(info_table)
        elements.append(Spacer(1, 20))
        
        # Résumé exécutif avec emojis et code couleur
        elements.append(Paragraph("📊 Résumé Exécutif", section_style))
        
        summary_data = [
            ['Métrique', 'Valeur', 'Objectif/Seuil'],
            ['📏 Lignes de code', f"{int(project_data.get('ncloc', 0) or 0):,}", 'Information'],
            ['🐛 Bugs', project_data.get('bugs', '0'), '0 (Critique)'],
            ['🔐 Vulnérabilités', project_data.get('vulnerabilities', '0'), '0 (Critique)'],
            ['💨 Code Smells', project_data.get('code_smells', '0'), '< 50 (Recommandé)'],
            ['🧪 Couverture Tests', f"{project_data.get('coverage', '0')}%", '> 80% (Objectif)'],
            ['🔄 Duplication', f"{project_data.get('duplicated_lines_density', '0')}%", '< 3% (Objectif)'],
            ['⚡ Complexité Cognitive', project_data.get('cognitive_complexity', '0'), 'Information'],
            ['🏆 Note Maintenabilité', project_data.get('sqale_rating', 'N/A'), 'A (Objectif)'],
            ['🛡️ Note Fiabilité', project_data.get('reliability_rating', 'N/A'), 'A (Objectif)'],
            ['🔒 Note Sécurité', project_data.get('security_rating', 'N/A'), 'A (Objectif)']
        ]
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 1.5*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
        elements.append(PageBreak())
        
        # Section Issues détaillées
        elements.append(Paragraph("🚨 Issues à Corriger (Détaillées)", section_style))
        
        total_issues = issues_data.get('total_issues', 0)
        elements.append(Paragraph(f"<b>Total: {total_issues} issues à corriger</b>", styles['Normal']))
        elements.append(Spacer(1, 10))
        
        if total_issues > 0:
            # Répartition par sévérité avec priorités
            elements.append(Paragraph("Répartition par Sévérité", subsection_style))
            severity_data = [['Sévérité', 'Nombre', 'Priorité de correction']]
            severity_order = ['BLOCKER', 'CRITICAL', 'MAJOR', 'MINOR', 'INFO']
            
            for severity in severity_order:
                count = issues_data.get('by_severity', {}).get(severity, 0)
                priority = {'BLOCKER': '🔴 IMMÉDIATE', 'CRITICAL': '🟠 HAUTE', 
                          'MAJOR': '🟡 MOYENNE', 'MINOR': '🔵 BASSE', 'INFO': '⚪ INFO'}
                if count > 0:
                    severity_data.append([severity, str(count), priority.get(severity, '')])
            
            if len(severity_data) > 1:
                severity_table = Table(severity_data, colWidths=[2*inch, 1*inch, 2*inch])
                severity_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                elements.append(severity_table)
            elements.append(Spacer(1, 15))
            
            # Top 10 des fichiers les plus problématiques
            elements.append(Paragraph("📁 Fichiers les Plus Problématiques", subsection_style))
            file_data = [['Fichier', 'Nb Issues', 'Action recommandée']]
            
            for file_path, issue_count in issues_data.get('most_problematic_files', [])[:10]:
                action = "🔥 Refactoring prioritaire" if issue_count > 10 else "🔧 Correction ciblée"
                # Tronquer le nom du fichier pour l'affichage
                display_file = file_path[-40:] if len(file_path) > 40 else file_path
                file_data.append([display_file, str(issue_count), action])
            
            if len(file_data) > 1:
                file_table = Table(file_data, colWidths=[3*inch, 1*inch, 2*inch])
                file_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 8),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                elements.append(file_table)
            
            elements.append(PageBreak())
            
            # Issues détaillées par sévérité (limitées pour éviter un PDF trop volumineux)
            for severity in ['BLOCKER', 'CRITICAL', 'MAJOR']:
                severity_issues = [issue for issue in issues_data.get('issues', []) 
                                 if issue['severity'] == severity]
                
                if severity_issues:
                    elements.append(Paragraph(f"🚨 Issues {severity} - Correction Urgente", subsection_style))
                    
                    issue_data = [['Fichier:Ligne', 'Règle', 'Message', 'Effort']]
                    
                    # Limiter à 20 issues par sévérité pour éviter un PDF trop lourd
                    for issue in severity_issues[:20]:
                        file_line = f"{issue['component']}:{issue['line']}"
                        rule = issue['rule'].split(':')[-1] if issue['rule'] else 'N/A'
                        message = issue['message'][:60] + "..." if len(issue['message']) > 60 else issue['message']
                        effort = issue.get('effort', 'N/A')
                        
                        issue_data.append([file_line[-35:], rule, message, effort])
                    
                    if len(severity_issues) > 20:
                        issue_data.append(['...', f"+{len(severity_issues)-20} autres", 
                                         "Voir SonarQube pour la liste complète", "..."])
                    
                    issue_table = Table(issue_data, colWidths=[2*inch, 1.5*inch, 2.5*inch, 0.7*inch])
                    issue_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, -1), 7),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black),
                        ('VALIGN', (0, 0), (-1, -1), 'TOP')
                    ]))
                    elements.append(issue_table)
                    elements.append(Spacer(1, 15))
        
        # Section Security Hotspots
        if hotspots:
            elements.append(PageBreak())
            elements.append(Paragraph("🔥 Security Hotspots à Réviser", section_style))
            elements.append(Paragraph(f"<b>Total: {len(hotspots)} hotspots à réviser</b>", styles['Normal']))
            elements.append(Spacer(1, 10))
            
            hotspot_data = [['Fichier:Ligne', 'Règle', 'Message', 'Probabilité']]
            
            for hotspot in hotspots[:30]:  # Limite à 30 hotspots
                file_line = f"{hotspot['component']}:{hotspot['line']}"
                rule = hotspot['rule'].split(':')[-1] if hotspot['rule'] else 'N/A'
                message = hotspot['message'][:50] + "..." if len(hotspot['message']) > 50 else hotspot['message']
                probability = hotspot.get('vulnerabilityProbability', 'LOW')
                
                hotspot_data.append([file_line[-35:], rule, message, probability])
            
            hotspot_table = Table(hotspot_data, colWidths=[2*inch, 1.5*inch, 2.5*inch, 1*inch])
            hotspot_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            elements.append(hotspot_table)
        
        # Recommandations d'action personnalisées
        elements.append(PageBreak())
        elements.append(Paragraph("💡 Plan d'Action Personnalisé", section_style))
        
        recommendations = []
        
        # Analyse automatique des priorités basée sur les métriques réelles
        bugs = int(project_data.get('bugs', 0) or 0)
        vulnerabilities = int(project_data.get('vulnerabilities', 0) or 0)
        blockers = issues_data.get('by_severity', {}).get('BLOCKER', 0)
        criticals = issues_data.get('by_severity', {}).get('CRITICAL', 0)
        majors = issues_data.get('by_severity', {}).get('MAJOR', 0)
        coverage = float(project_data.get('coverage', 0) or 0)
        duplication = float(project_data.get('duplicated_lines_density', 0) or 0)
        
        # Priorité 1: Issues bloquantes
        if blockers > 0:
            recommendations.append(f"🔴 <b>PRIORITÉ 1 - URGENT</b>: Corriger {blockers} issue(s) BLOCKER immédiatement. Ces issues empêchent le passage en production.")
        
        # Priorité 2: Issues critiques et vulnérabilités
        if criticals > 0:
            recommendations.append(f"🟠 <b>PRIORITÉ 2 - CRITIQUE</b>: Corriger {criticals} issue(s) CRITICAL dans les 48h.")
        
        if vulnerabilities > 0:
            recommendations.append(f"🔐 <b>PRIORITÉ 2 - SÉCURITÉ</b>: Traiter {vulnerabilities} vulnérabilité(s) de sécurité. Risque de faille de sécurité.")
        
        # Priorité 3: Issues majeures et couverture
        if majors > 0:
            recommendations.append(f"🟡 <b>PRIORITÉ 3</b>: Traiter {majors} issue(s) MAJOR dans le prochain sprint.")
        
        if coverage < 50:
            recommendations.append(f"🧪 <b>PRIORITÉ 3 - TESTS</b>: Améliorer la couverture de tests (actuel: {coverage}%, objectif: >80%). Ajouter des tests unitaires.")
        elif coverage < 80:
            recommendations.append(f"🧪 <b>AMÉLIORATION</b>: Continuer à améliorer la couverture de tests ({coverage}% → objectif: 80%+).")
        
        # Recommandations de refactoring
        if duplication > 10:
            recommendations.append(f"🔄 <b>REFACTORING</b>: Réduire la duplication de code (actuel: {duplication}%). Extraire les fonctions communes.")
        
        if bugs > 20:
            recommendations.append(f"🐛 <b>QUALITÉ</b>: Corriger {bugs} bug(s) détecté(s). Réviser les processus de développement.")
        
        # Messages positifs
        if not recommendations:
            recommendations.append("✅ <b>EXCELLENT</b>: Projet en excellente santé ! Maintenir la qualité actuelle et continuer les bonnes pratiques.")
        elif total_issues < 10:
            recommendations.append("👍 <b>BON TRAVAIL</b>: Peu d'issues détectées. Projet globalement de bonne qualité.")
        
        # Recommandations spécifiques basées sur les fichiers problématiques
        top_files = issues_data.get('most_problematic_files', [])
        if top_files and len(top_files) > 0:
            worst_file, worst_count = top_files[0]
            if worst_count > 15:
                recommendations.append(f"📁 <b>FICHIER CRITIQUE</b>: Le fichier '{worst_file}' contient {worst_count} issues. Priorité absolue pour le refactoring.")
        
        # Affichage des recommandations
        for i, rec in enumerate(recommendations, 1):
            elements.append(Paragraph(f"{i}. {rec}", styles['Normal']))
            elements.append(Spacer(1, 8))
        
        # Section liens utiles
        elements.append(Spacer(1, 20))
        elements.append(Paragraph("🔗 Liens Utiles", section_style))
        
        links = [
            f"• <b>Dashboard du projet</b>: {self.sonar_url}/dashboard?id={project_data.get('project_key')}",
            f"• <b>Issues du projet</b>: {self.sonar_url}/project/issues?id={project_data.get('project_key')}",
            f"• <b>Couverture de tests</b>: {self.sonar_url}/component_measures?id={project_data.get('project_key')}&metric=coverage",
            f"• <b>Security Hotspots</b>: {self.sonar_url}/security_hotspots?id={project_data.get('project_key')}"
        ]
        
        for link in links:
            elements.append(Paragraph(link, styles['Normal']))
            elements.append(Spacer(1, 5))
        
        # Footer
        elements.append(Spacer(1, 30))
        elements.append(HRFlowable(width="100%", thickness=1, lineCap='round', color=colors.grey))
        footer_style = ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.grey)
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(
            f"Rapport exhaustif généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')} par {self.company_name}<br/>"
            f"Version: SonarQube Comprehensive Reporter 2.0<br/>"
            f"Ce rapport contient toutes les informations nécessaires pour corriger les problèmes de qualité détectés.", 
            footer_style
        ))
        
        doc.build(elements)
        logger.info(f"Rapport exhaustif créé: {filename}")

    def send_comprehensive_email_report(self, summary_pdf: str, project_pdfs: List[str], summary: Dict):
        """Envoie les rapports par email avec le rapport de synthèse et les rapports par projet en ZIP."""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_sender
            msg['To'] = ', '.join(self.recipients)
            msg['Subject'] = f"[CSI] 📊 Rapports Exhaustifs SonarQube - {datetime.now().strftime('%B %Y')}"
            
            # Corps de l'email HTML amélioré
            html_body = f"""
            <html>
            <head>
                <style>
                    body {{ font-family: Arial, sans-serif; color: #333; line-height: 1.6; }}
                    .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; text-align: center; }}
                    .content {{ padding: 25px; }}
                    .summary-table {{ border-collapse: collapse; width: 100%; margin: 20px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
                    .summary-table th, .summary-table td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
                    .summary-table th {{ background-color: #f8f9fa; font-weight: bold; }}
                    .summary-table tr:nth-child(even) {{ background-color: #f8f9fa; }}
                    .action-box {{ background: linear-gradient(135deg, #ffeaa7 0%, #fab1a0 100%); border-left: 5px solid #e17055; padding: 20px; margin: 20px 0; border-radius: 5px; }}
                    .highlight-box {{ background-color: #e8f5e8; border: 2px solid #28a745; padding: 15px; margin: 15px 0; border-radius: 5px; }}
                    .footer {{ font-size: 12px; color: #666; margin-top: 30px; text-align: center; padding-top: 20px; border-top: 1px solid #eee; }}
                    .emoji {{ font-size: 1.2em; }}
                </style>
            </head>
            <body>
                <div class="header">
                    <h1 class="emoji">📊 Rapports Exhaustifs de Qualité du Code</h1>
                    <h2>{self.company_name} - DevSecOps</h2>
                    <h3>{datetime.now().strftime('%B %Y')}</h3>
                </div>
                <div class="content">
                    <p><strong>Bonjour l'équipe DevSecOps et les développeurs,</strong></p>
                    
                    <p>Les rapports exhaustifs de qualité du code SonarQube sont prêts ! Cette version améliorée fournit un niveau de détail sans précédent pour permettre une correction efficace de tous les problèmes détectés.</p>
                    
                    <div class="highlight-box">
                        <h3 class="emoji">🎯 <strong>Nouveautés de cette version</strong></h3>
                        <ul>
                            <li><strong>Un rapport détaillé par projet</strong> avec localisation exacte des issues</li>
                            <li><strong>Plan d'action personnalisé</strong> pour chaque projet</li>
                            <li><strong>Prioritisation automatique</strong> des corrections (BLOCKER, CRITICAL, etc.)</li>
                            <li><strong>Fichiers les plus problématiques</strong> identifiés</li>
                            <li><strong>Security hotspots</strong> détaillés avec probabilité de risque</li>
                            <li><strong>Liens directs</strong> vers SonarQube pour chaque issue</li>
                        </ul>
                    </div>
                    
                    <h3 class="emoji">📈 Résumé Exécutif Global</h3>
                    <table class="summary-table">
                        <tr><th>Métrique</th><th>Valeur</th><th>Statut</th></tr>
                        <tr><td class="emoji">📁 Projets analysés</td><td>{summary['total_projects']}</td><td>Information</td></tr>
                        <tr><td class="emoji">📏 Lignes de code totales</td><td>{summary['total_lines']:,}</td><td>Information</td></tr>
                        <tr><td class="emoji">🚨 Issues totales à corriger</td><td>{summary.get('total_issues', 'N/A')}</td><td>{'🔴 Action requise' if summary.get('total_issues', 0) > 0 else '✅ Excellent'}</td></tr>
                        <tr><td class="emoji">🐛 Bugs détectés</td><td>{summary['total_bugs']}</td><td>{'🔴 Critique' if summary['total_bugs'] > 0 else '✅ Aucun'}</td></tr>
                        <tr><td class="emoji">🔐 Vulnérabilités</td><td>{summary['total_vulnerabilities']}</td><td>{'🔴 Critique' if summary['total_vulnerabilities'] > 0 else '✅ Aucune'}</td></tr>
                        <tr><td class="emoji">💨 Code smells</td><td>{summary['total_code_smells']}</td><td>{'🟡 À améliorer' if summary['total_code_smells'] > 100 else '✅ Acceptable'}</td></tr>
                        <tr><td class="emoji">🧪 Couverture moyenne</td><td>{summary['avg_coverage']:.1f}%</td><td>{'✅ Excellent' if summary['avg_coverage'] >= 80 else '🟡 À améliorer' if summary['avg_coverage'] >= 50 else '🔴 Insuffisant'}</td></tr>
                    </table>
                    
                    <h3 class="emoji">📦 Contenu de l'envoi</h3>
                    <ul>
                        <li><strong class="emoji">📊 Synthèse globale</strong> : Vue d'ensemble consolidée de tous les projets</li>
                        <li><strong class="emoji">📁 Archive ZIP des rapports détaillés</strong> : Un rapport exhaustif par projet ({len(project_pdfs)} rapports)</li>
                    </ul>
                    
                    <div class="action-box">
                        <h4 class="emoji">🎯 Guide d'utilisation pour les équipes</h4>
                        
                        <p><strong class="emoji">👨‍💻 Pour les développeurs :</strong></p>
                        <ol>
                            <li><strong>Téléchargez l'archive ZIP</strong> et extrayez le rapport de votre projet</li>
                            <li><strong>Consultez le "Plan d'Action Personnalisé"</strong> en fin de rapport</li>
                            <li><strong>Priorisez les corrections</strong> : BLOCKER → CRITICAL → MAJOR</li>
                            <li><strong>Utilisez les informations "Fichier:Ligne"</strong> pour localiser rapidement les issues</li>
                            <li><strong>Cliquez sur les liens SonarQube</strong> pour plus de détails sur chaque règle</li>
                        </ol>
                        
                        <p><strong class="emoji">👨‍💼 Pour les leads et managers :</strong></p>
                        <ol>
                            <li><strong>Consultez la synthèse globale</strong> pour identifier les projets prioritaires</li>
                            <li><strong>Planifiez les sprints</strong> en incluant la correction des issues critiques</li>
                            <li><strong>Suivez l'évolution</strong> mensuelle des métriques de qualité</li>
                            <li><strong>Identifiez les projets</strong> nécessitant du refactoring</li>
                        </ol>
                    </div>
                    
                    <h3 class="emoji">📋 Contenu de chaque rapport de projet</h3>
                    <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0;">
                        <ul>
                            <li class="emoji">📊 <strong>Métriques complètes</strong> : couverture, complexité, duplication, dette technique</li>
                            <li class="emoji">🚨 <strong>Issues détaillées par sévérité</strong> avec localisation exacte (fichier:ligne)</li>
                            <li class="emoji">📁 <strong>Top 10 des fichiers problématiques</strong> à refactoriser en priorité</li>
                            <li class="emoji">🔥 <strong>Security hotspots</strong> avec probabilité de risque</li>
                            <li class="emoji">💡 <strong>Plan d'action personnalisé</strong> basé sur l'état réel du projet</li>
                            <li class="emoji">🔗 <strong>Liens directs</strong> vers SonarQube pour approfondir l'analyse</li>
                            <li class="emoji">🎯 <strong>Objectifs de qualité</strong> et seuils recommandés</li>
                        </ul>
                    </div>
                    
                    <div class="footer">
                        <p><strong>Rapports générés automatiquement le {datetime.now().strftime('%d/%m/%Y à %H:%M')}</strong><br>
                        Système de reporting SonarQube {self.company_name} - Version 2.0 (Exhaustif)<br>
                        <a href="{self.sonar_url}" style="color: #667eea;">🔗 Accès direct à SonarQube</a></p>
                        
                        <p style="margin-top: 20px; font-style: italic;">
                            "La qualité n'est pas un accident, c'est le résultat d'un effort intelligent." - John Ruskin
                        </p>
                    </div>
                </div>
            </body>
            </html>
            """
            
            msg.attach(MIMEText(html_body, 'html', 'utf-8'))
            
            # Pièce jointe - Rapport de synthèse
            with open(summary_pdf, "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename={os.path.basename(summary_pdf)}')
            msg.attach(part)
            
            # Pièce jointe - Archive ZIP des rapports détaillés
            if project_pdfs:
                zip_filename = f"reports/rapports_detailles_projets_{datetime.now().strftime('%Y%m')}.zip"
                with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for pdf_file in project_pdfs:
                        if os.path.exists(pdf_file):
                            zipf.write(pdf_file, os.path.basename(pdf_file))
                
                with open(zip_filename, "rb") as attachment:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(attachment.read())
                
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename={os.path.basename(zip_filename)}')
                msg.attach(part)
            
            # Envoi via SMTP CSI (sans authentification)
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.sendmail(self.email_sender, self.recipients, msg.as_string())
            
            logger.info(f"Rapports exhaustifs envoyés par email à: {', '.join(self.recipients)}")
            
        except Exception as e:
            logger.error(f"Erreur lors de l'envoi de l'email: {e}")
            raise

    def create_summary_report(self, projects_data: List[Dict], projects_issues: Dict, filename: str):
        """Crée un rapport de synthèse de tous les projets."""
        doc = SimpleDocTemplate(filename, pagesize=A4)
        elements = []
        styles = getSampleStyleSheet()
        
        # Titre principal
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=20,
            spaceAfter=30,
            textColor=colors.darkblue,
            alignment=1
        )
        
        current_date = datetime.now().strftime("%B %Y")
        title = Paragraph(f"📊 Synthèse Globale - Qualité du Code<br/>{self.company_name} - {current_date}", title_style)
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Résumé exécutif global
        total_projects = len(projects_data)
        total_lines = sum(int(p.get('ncloc', 0) or 0) for p in projects_data)
        total_bugs = sum(int(p.get('bugs', 0) or 0) for p in projects_data)
        total_vulnerabilities = sum(int(p.get('vulnerabilities', 0) or 0) for p in projects_data)
        total_code_smells = sum(int(p.get('code_smells', 0) or 0) for p in projects_data)
        total_issues = sum(projects_issues[p['project_key']].get('total_issues', 0) for p in projects_data)
        
        # Calcul de la couverture moyenne
        coverages = [float(p.get('coverage', 0) or 0) for p in projects_data if p.get('coverage')]
        avg_coverage = sum(coverages) / len(coverages) if coverages else 0
        
        summary_data = [
            ['Vue d\'ensemble', 'Valeur', 'Statut'],
            ['Nombre total de projets', str(total_projects), 'ℹ️ Information'],
            ['Lignes de code totales', f"{total_lines:,}", 'ℹ️ Information'],
            ['Issues totales à corriger', str(total_issues), '🔴 Action requise' if total_issues > 0 else '✅ Excellent'],
            ['Bugs totaux', str(total_bugs), '🔴 Critique' if total_bugs > 0 else '✅ Aucun'],
            ['Vulnérabilités totales', str(total_vulnerabilities), '🔴 Critique' if total_vulnerabilities > 0 else '✅ Aucune'],
            ['Code smells totaux', str(total_code_smells), '🟡 À améliorer' if total_code_smells > 100 else '✅ Acceptable'],
            ['Couverture moyenne', f"{avg_coverage:.1f}%", '✅ Excellent' if avg_coverage >= 80 else '🟡 À améliorer' if avg_coverage >= 50 else '🔴 Insuffisant']
        ]
        
        summary_table = Table(summary_data, colWidths=[2.5*inch, 1.5*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
        elements.append(PageBreak())
        
        # Tableau des projets avec statut qualité détaillé
        section_style = ParagraphStyle('SectionHeader', parent=styles['Heading2'], 
                                     fontSize=14, textColor=colors.darkgreen)
        elements.append(Paragraph("📊 État de la Qualité par Projet", section_style))
        
        project_headers = [
            'Projet', 'Issues', 'Bugs', 'Vulné.', 'Couv.%', 'Note', 'Statut Priorité'
        ]
        
        project_data = [project_headers]
        
        # Trier les projets par nombre d'issues critiques (bugs + vulnérabilités)
        sorted_projects = sorted(projects_data, 
                               key=lambda p: int(p.get('bugs', 0) or 0) + int(p.get('vulnerabilities', 0) or 0), 
                               reverse=True)
        
        for project in sorted_projects:
            project_key = project.get('project_key')
            issues_count = projects_issues.get(project_key, {}).get('total_issues', 0)
            bugs = int(project.get('bugs', 0) or 0)
            vulnerabilities = int(project.get('vulnerabilities', 0) or 0)
            coverage = project.get('coverage', '0')
            sqale_rating = project.get('sqale_rating', 'A')
            
            # Déterminer le statut priorité
            if bugs > 0 or vulnerabilities > 0:
                priority_status = "🔴 URGENT"
            elif issues_count > 50:
                priority_status = "🟠 HAUTE"
            elif issues_count > 20:
                priority_status = "🟡 MOYENNE"
            elif issues_count > 0:
                priority_status = "🔵 BASSE"
            else:
                priority_status = "✅ Excellent"
            
            project_data.append([
                project.get('project_name', 'N/A')[:20],  # Tronquer le nom
                str(issues_count),
                str(bugs),
                str(vulnerabilities),
                coverage,
                sqale_rating,
                priority_status
            ])
        
        project_table = Table(project_data, colWidths=[2*inch, 0.7*inch, 0.7*inch, 0.7*inch, 0.7*inch, 0.6*inch, 1.1*inch])
        project_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('FONTSIZE', (0, 1), (-1, -1), 7),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(project_table)
        elements.append(Spacer(1, 20))
        
        # Plan d'action global avec recommandations concrètes
        elements.append(Paragraph("🎯 Plan d'Action Global Recommandé", section_style))
        
        # Projets prioritaires (avec bugs ou vulnérabilités)
        critical_projects = [p for p in projects_data 
                           if int(p.get('bugs', 0) or 0) > 0 or int(p.get('vulnerabilities', 0) or 0) > 0]
        
        if critical_projects:
            elements.append(Paragraph("🔴 <b>ACTIONS IMMÉDIATES (Projets Critiques):</b>", styles['Normal']))
            for i, project in enumerate(critical_projects[:5], 1):  # Top 5
                bugs = int(project.get('bugs', 0) or 0)
                vulns = int(project.get('vulnerabilities', 0) or 0)
                elements.append(Paragraph(
                    f"{i}. <b>{project.get('project_name', 'N/A')}</b> - "
                    f"{bugs} bugs, {vulns} vulnérabilités → Correction prioritaire requise",
                    styles['Normal']
                ))
            elements.append(Spacer(1, 15))
        
        # Projets avec beaucoup d'issues
        high_issue_projects = [p for p in projects_data 
                              if projects_issues.get(p['project_key'], {}).get('total_issues', 0) > 50]
        
        if high_issue_projects:
            elements.append(Paragraph("🟡 <b>ACTIONS À MOYEN TERME (Refactoring):</b>", styles['Normal']))
            for i, project in enumerate(high_issue_projects[:3], 1):  # Top 3
                issues_count = projects_issues.get(project['project_key'], {}).get('total_issues', 0)
                elements.append(Paragraph(
                    f"{i}. <b>{project.get('project_name', 'N/A')}</b> - "
                    f"{issues_count} issues → Planifier refactoring",
                    styles['Normal']
                ))
            elements.append(Spacer(1, 15))
        
        # Recommandations générales
        elements.append(Paragraph("📋 <b>RECOMMANDATIONS GÉNÉRALES:</b>", styles['Normal']))
        general_recommendations = [
            f"• Établir un objectif de <b>0 bug et 0 vulnérabilité</b> pour tous les projets",
            f"• Augmenter la couverture de tests moyenne à <b>80%+</b> (actuellement {avg_coverage:.1f}%)",
            f"• Intégrer SonarQube dans les pipelines CI/CD avec quality gates",
            f"• Formation des équipes sur les règles de qualité les plus fréquentes",
            f"• Révision de code systématique avant merge"
        ]
        
        for rec in general_recommendations:
            elements.append(Paragraph(rec, styles['Normal']))
            elements.append(Spacer(1, 5))
        
        # Footer avec informations sur les rapports détaillés
        elements.append(Spacer(1, 30))
        elements.append(HRFlowable(width="100%", thickness=1, lineCap='round', color=colors.grey))
        footer_style = ParagraphStyle('Footer', parent=styles['Normal'], fontSize=10, textColor=colors.darkblue)
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(
            "<b>📁 Rapports détaillés par projet disponibles dans l'archive ZIP jointe</b><br/>"
            f"Chaque projet dispose d'un rapport exhaustif de {len(projects_data)} pages en moyenne avec :<br/>"
            "• Localisation exacte de chaque issue (fichier:ligne)<br/>"
            "• Plan d'action personnalisé par projet<br/>"
            "• Liens directs vers SonarQube<br/>"
            "• Recommandations de correction prioritaire<br/><br/>"
            f"<i>Généré automatiquement le {datetime.now().strftime('%d/%m/%Y à %H:%M')} - "
            f"SonarQube Comprehensive Reporter v2.0</i>",
            footer_style
        ))
        
        doc.build(elements)
        logger.info(f"Rapport de synthèse créé: {filename}")

    def generate_summary_data(self, projects_data: List[Dict]) -> Dict:
        """Génère les données de résumé global."""
        total_projects = len(projects_data)
        total_lines = sum(int(p.get('ncloc', 0) or 0) for p in projects_data)
        total_bugs = sum(int(p.get('bugs', 0) or 0) for p in projects_data)
        total_vulnerabilities = sum(int(p.get('vulnerabilities', 0) or 0) for p in projects_data)
        total_code_smells = sum(int(p.get('code_smells', 0) or 0) for p in projects_data)
        
        # Calcul de la couverture moyenne
        coverages = [float(p.get('coverage', 0) or 0) for p in projects_data if p.get('coverage')]
        avg_coverage = sum(coverages) / len(coverages) if coverages else 0
        
        # Projets avec des problèmes critiques
        projects_with_bugs = len([p for p in projects_data if int(p.get('bugs', 0) or 0) > 0])
        projects_with_vulnerabilities = len([p for p in projects_data if int(p.get('vulnerabilities', 0) or 0) > 0])
        
        return {
            'total_projects': total_projects,
            'total_lines': total_lines,
            'total_bugs': total_bugs,
            'total_vulnerabilities': total_vulnerabilities,
            'total_code_smells': total_code_smells,
            'avg_coverage': round(avg_coverage, 1),
            'projects_with_bugs': projects_with_bugs,
            'projects_with_vulnerabilities': projects_with_vulnerabilities
        }

    def generate_comprehensive_monthly_reports(self):
        """Génère tous les rapports exhaustifs."""
        logger.info("Début de la génération des rapports exhaustifs SonarQube v2.0")
        
        try:
            # Création des dossiers nécessaires
            os.makedirs('logs', exist_ok=True)
            os.makedirs('reports', exist_ok=True)
            os.makedirs('backup', exist_ok=True)
            
            # Récupération des projets
            projects = self.get_projects()
            if not projects:
                logger.warning("Aucun projet trouvé")
                return
            
            # Récupération des données exhaustives pour chaque projet
            projects_data = []
            projects_issues = {}
            project_pdfs = []
            
            timestamp = datetime.now().strftime("%Y%m")
            
            logger.info(f"Traitement de {len(projects)} projets...")
            
            for i, project in enumerate(projects, 1):
                project_key = project['key']
                logger.info(f"[{i}/{len(projects)}] Traitement exhaustif du projet: {project_key}")
                
                # Métriques complètes
                metrics = self.get_project_comprehensive_metrics(project_key)
                projects_data.append(metrics)
                
                # Issues détaillées
                issues_data = self.get_project_issues_detailed(project_key)
                projects_issues[project_key] = issues_data
                logger.info(f"  → {issues_data['total_issues']} issues trouvées")
                
                # Security hotspots
                hotspots = self.get_project_hotspots(project_key)
                logger.info(f"  → {len(hotspots)} security hotspots trouvés")
                
                # Création du rapport détaillé par projet
                safe_project_name = project_key.replace(':', '_').replace('/', '_').replace(' ', '_')
                project_filename = f"reports/rapport_detaille_{safe_project_name}_{timestamp}.pdf"
                
                self.create_project_comprehensive_report(metrics, issues_data, hotspots, project_filename)
                project_pdfs.append(project_filename)
                logger.info(f"  ✓ Rapport créé: {os.path.basename(project_filename)}")
            
            # Génération du résumé global avec statistiques étendues
            total_issues = sum(projects_issues[p['project_key']].get('total_issues', 0) for p in projects_data)
            summary = self.generate_summary_data(projects_data)
            summary['total_issues'] = total_issues
            
            logger.info(f"Statistiques globales: {total_issues} issues, {summary['total_bugs']} bugs, {summary['total_vulnerabilities']} vulnérabilités")
            
            # Création du rapport de synthèse
            summary_filename = f"reports/synthese_globale_qualite_{timestamp}.pdf"
            self.create_summary_report(projects_data, projects_issues, summary_filename)
            
            # Envoi des rapports par email
            logger.info("Envoi des rapports par email...")
            self.send_comprehensive_email_report(summary_filename, project_pdfs, summary)
            
            logger.info("=" * 60)
            logger.info("🎉 RAPPORTS EXHAUSTIFS GÉNÉRÉS AVEC SUCCÈS !")
            logger.info("=" * 60)
            logger.info(f"📊 Rapport de synthèse: {summary_filename}")
            logger.info(f"📁 Rapports détaillés: {len(project_pdfs)} projets")
            logger.info(f"📧 Envoyés à: {', '.join(self.recipients)}")
            logger.info(f"📈 Total issues à corriger: {total_issues}")
            logger.info("=" * 60)
            
        except Exception as e:
            logger.error(f"Erreur lors de la génération des rapports: {e}")
            raise

def main():
    """Point d'entrée principal."""
    try:
        reporter = SonarQubeComprehensiveReporter()
        reporter.generate_comprehensive_monthly_reports()
    except Exception as e:
        logger.error(f"Erreur fatale: {e}")
        return 1
    return 0

if __name__ == "__main__":
    exit(main())
